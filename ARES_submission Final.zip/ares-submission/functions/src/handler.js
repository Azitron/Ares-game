'use strict';

const { RateLimiter } = require('./RateLimiter');
const { MAX_EVENT_LENGTH, COMMENTARY_SYSTEM, DECISION_SYSTEM, cleanBoard } = require('./prompts');

const BEARER = /^Bearer (.+)$/;

const applyCors = (req, res, allowed) => {
  const origin = req.get('origin') || '';
  const permitted = allowed().includes(origin);
  if (permitted) {
    res.set('Access-Control-Allow-Origin', origin);
    res.set('Vary', 'Origin');
    res.set('Access-Control-Allow-Headers', 'Authorization, Content-Type');
    res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
  }
  return { origin, permitted };
};

const commentary = async (body, chat) => {
  const event = String(body.event || '').slice(0, MAX_EVENT_LENGTH);
  if (!event) return { status: 400, body: { error: 'event_required' } };
  const text = await chat([
    { role: 'system', content: COMMENTARY_SYSTEM },
    { role: 'user', content: event },
  ]);
  return { status: 200, body: { text: text.replace(/\s+/g, ' ').trim().slice(0, 260) } };
};

const parseJson = (text) => {
  const match = /\{[\s\S]*\}/.exec(text);
  try {
    return match ? JSON.parse(match[0]) : {};
  } catch (error) {
    return {};
  }
};

const decision = async (body, chat) => {
  const cleaned = cleanBoard(body);
  if (!cleaned) return { status: 400, body: { error: 'bad_board' } };
  const text = await chat([
    { role: 'system', content: DECISION_SYSTEM },
    { role: 'user', content: JSON.stringify(cleaned) },
  ]);
  const parsed = parseJson(text);
  const from = cleaned.board.find((c) => c.n === parsed.from && c.o === cleaned.me && c.s >= 2);
  const to = cleaned.board.find((c) => c.n === parsed.to && c.o !== cleaned.me);
  if (!from || !to) return { status: 200, body: { from: null, why: String(parsed.why || 'No good target.').slice(0, 140) } };
  return { status: 200, body: { from: from.n, to: to.n, why: String(parsed.why || '').slice(0, 140) } };
};

const ROUTES = Object.freeze({ commentary, decide: decision });

const makeHandler = ({ origins, verify, chat, limiter = new RateLimiter() }) => async (req, res) => {
  const { origin, permitted } = applyCors(req, res, origins);
  if (req.method === 'OPTIONS') return res.status(permitted ? 204 : 403).send('');
  if (req.method !== 'POST') return res.status(405).json({ error: 'post_only' });
  if (origin && !permitted) return res.status(403).json({ error: 'origin_not_allowed' });

  const match = BEARER.exec(req.get('authorization') || '');
  if (!match) return res.status(401).json({ error: 'login_required' });
  let uid;
  try {
    uid = (await verify(match[1])).uid;
  } catch (error) {
    return res.status(401).json({ error: 'bad_token' });
  }
  if (limiter.isLimited(uid)) return res.status(429).json({ error: 'slow_down' });

  const body = req.body || {};
  const route = ROUTES[body.type];
  if (!route) return res.status(400).json({ error: 'unknown_type' });
  try {
    const result = await route(body, chat);
    return res.status(result.status).json(result.body);
  } catch (error) {
    console.error('llm_failed', String(error.message || error).slice(0, 300));
    return res.status(502).json({ error: 'llm_failed' });
  }
};

module.exports = { makeHandler };
