'use strict';

const ENDPOINT = 'https://api.openai.com/v1/chat/completions';

const createChat = ({ apiKey, model, timeoutMs = 25000, fetchFn = fetch }) => async (messages) => {
  const response = await fetchFn(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey()}` },
    body: JSON.stringify({ model: model(), messages }),
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!response.ok) throw new Error(`OpenAI ${response.status} ${(await response.text()).slice(0, 300)}`);
  const json = await response.json();
  return json.choices?.[0]?.message?.content || '';
};

module.exports = { createChat };
