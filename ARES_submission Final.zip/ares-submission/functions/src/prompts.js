'use strict';

const MAX_EVENT_LENGTH = 400;

const COMMENTARY_SYSTEM =
  'You are the live war commentator for "Ares", a cyberpunk Risk-style geopolitics game. ' +
  'You receive one battle event. Write ONE vivid sentence, at most 30 words, in the present tense. ' +
  'Use only facts in the event (country names, dice, losses). ' +
  'Notation: "[a,b]" are dice rolls; "-> -X/-Y" means the attacker lost X soldiers and the defender lost Y. ' +
  'No emojis, no hashtags, no quotation marks.';

const DECISION_SYSTEM =
  'You pick the next attack for an NPC in a Risk-style game. Rules: a country needs 2+ soldiers to attack; ' +
  "an attack uses (attacker soldiers - 1) dice against the defender's soldiers; the higher die wins each pair and ties kill nobody; " +
  'conquering a country gives max(2, floor(base/2)) soldiers. In the board, "o" is the owner id, "s" is soldiers and "me" is your owner id. ' +
  '"from" must be a country you own (o equals me) with s >= 2, and "to" must be a country you do not own. ' +
  'Reply with ONLY JSON: {"from":"<name>","to":"<name>","why":"<max 20 words>"} or {"from":null,"why":"<reason>"} to hold.';

const cleanBoard = (body) => {
  if (!Array.isArray(body.board) || body.board.length < 2 || body.board.length > 10) return null;
  if (!Number.isInteger(body.me) || body.me < 0 || body.me > 9) return null;
  const board = body.board.map((c) => ({ n: String(c.n || '').slice(0, 40), o: c.o | 0, s: c.s | 0 }));
  return board.every((c) => c.n) ? { me: body.me, board } : null;
};

module.exports = { MAX_EVENT_LENGTH, COMMENTARY_SYSTEM, DECISION_SYSTEM, cleanBoard };
