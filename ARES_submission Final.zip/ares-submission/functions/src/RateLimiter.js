'use strict';

class RateLimiter {
  #max;
  #windowMs;
  #hits = new Map();

  constructor({ max = 120, windowMs = 60000 } = {}) {
    this.#max = max;
    this.#windowMs = windowMs;
  }

  isLimited(key, now = Date.now()) {
    const recent = (this.#hits.get(key) ?? []).filter((time) => now - time < this.#windowMs);
    recent.push(now);
    this.#hits.set(key, recent);
    return recent.length > this.#max;
  }

  reset() {
    this.#hits.clear();
  }
}

module.exports = { RateLimiter };
