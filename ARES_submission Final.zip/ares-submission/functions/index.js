'use strict';

const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret, defineString } = require('firebase-functions/params');
const admin = require('firebase-admin');
const { makeHandler } = require('./src/handler');
const { createChat } = require('./src/openai');

admin.initializeApp();

const OPENAI_API_KEY = defineSecret('OPENAI_API_KEY');
const OPENAI_MODEL = defineString('OPENAI_MODEL', { default: 'gpt-5.6-luna' });
const ALLOWED_ORIGINS = defineString('ALLOWED_ORIGINS', {
  default: 'https://ares-run-the-world.web.app,https://ares-run-the-world.firebaseapp.com,http://localhost:8080',
});

const chat = createChat({ apiKey: () => OPENAI_API_KEY.value(), model: () => OPENAI_MODEL.value() });

exports.aresLLM = onRequest(
  { secrets: [OPENAI_API_KEY], invoker: 'public', region: 'us-central1', maxInstances: 5, timeoutSeconds: 40 },
  makeHandler({
    origins: () => ALLOWED_ORIGINS.value().split(',').map((origin) => origin.trim()),
    verify: (token) => admin.auth().verifyIdToken(token),
    chat,
  }),
);
