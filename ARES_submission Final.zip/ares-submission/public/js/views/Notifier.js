import { mount, html } from '../utils/html.js';

export class Notifier {
  #element;
  #timer = null;

  constructor(element) {
    this.#element = element;
  }

  show(message, kind = 'error', durationMs = 0) {
    clearTimeout(this.#timer);
    mount(this.#element, html`<div class="toast ${kind}" role="${kind === 'error' ? 'alert' : 'status'}"><span>${message}</span><button type="button" data-act="dismiss" aria-label="Dismiss message">✕</button></div>`);
    if (durationMs > 0) this.#timer = setTimeout(() => this.clear(), durationMs);
  }

  clear() {
    clearTimeout(this.#timer);
    mount(this.#element, '');
  }
}
