import { html, mount } from '../utils/html.js';

export class Shell {
  #userBar;

  constructor(userBar) {
    this.#userBar = userBar;
  }

  renderUser(user) {
    mount(
      this.#userBar,
      user
        ? html`<span>Operator <b>${user.callsign}</b></span><button type="button" class="small" data-act="logout">Jack out</button>`
        : html`<span>Unplugged</span>`,
    );
  }
}
