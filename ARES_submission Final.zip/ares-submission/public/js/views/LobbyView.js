import { REQUIRED_COUNTRY } from '../config/rules.js';
import { html } from '../utils/html.js';

export class LobbyView {
  render({ countries, myPanel, publicPanel, stats }) {
    return html`<div class="lobby">
      <section class="panel" aria-labelledby="deploy-title">
        <h2 id="deploy-title">Pick your flag, operator</h2>
        <small>${REQUIRED_COUNTRY} always joins the grid, as you or as a rival.</small>
        <form id="deploy-form" class="row">
          <label class="sr-only" for="country">Your country</label>
          <select id="country" name="country">
            ${countries.map((c) => html`<option value="${c.name}" ${c.name === REQUIRED_COUNTRY ? 'selected' : ''}>${c.flag} ${c.name}</option>`)}
          </select>
          <button type="submit" class="hot">Deploy to the grid</button>
        </form>
        <div class="stats" id="stats">${this.stats(stats)}</div>
      </section>
      ${myPanel.shell()}
      ${publicPanel.shell()}
    </div>`;
  }

  stats({ total, live, won, lost }) {
    return [['Runs', total], ['Live', live], ['Won', won], ['Lost', lost]].map(
      ([label, value]) => html`<div class="stat"><b>${value}</b><small>${label}</small></div>`,
    );
  }
}
