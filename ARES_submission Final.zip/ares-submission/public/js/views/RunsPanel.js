import { STATUS } from '../models/GameSummary.js';
import { html } from '../utils/html.js';

const LABELS = Object.freeze({ [STATUS.LIVE]: 'LIVE', [STATUS.WON]: 'WON', [STATUS.LOST]: 'LOST' });

export class RunsPanel {
  #id;
  #title;
  #emptyText;
  #canDelete;

  constructor({ id, title, emptyText, canDelete = false }) {
    this.#id = id;
    this.#title = title;
    this.#emptyText = emptyText;
    this.#canDelete = canDelete;
  }

  get id() {
    return this.#id;
  }

  get itemsId() {
    return `${this.#id}-items`;
  }

  shell() {
    return html`<section class="panel runs" aria-labelledby="${this.#id}-title">
      <h3 id="${this.#id}-title">${this.#title}</h3>
      <div class="toolbar">
        <input type="search" data-filter="${this.#id}" data-field="q" maxlength="40" placeholder="Search country or operator" aria-label="Search ${this.#title}">
        <select data-filter="${this.#id}" data-field="status" aria-label="Filter ${this.#title} by status">
          <option value="all">All</option><option value="live">Live</option><option value="won">Won</option><option value="lost">Lost</option>
        </select>
      </div>
      <div id="${this.itemsId}" class="runs-list" aria-live="polite"><small>Loading…</small></div>
    </section>`;
  }

  items(runs, filtered) {
    if (!runs.length) return html`<small>${this.#emptyText}</small>`;
    if (!filtered.length) return html`<small>No runs match your search.</small>`;
    return filtered.map(
      (run) => html`<div class="run">
        <a class="run-link" href="?g=${run.id}" data-route>
          <span class="flag-dot">${run.flag}</span>
          <span class="run-main"><b>${run.country}</b><small>${run.ownerName} · round ${run.round}</small></span>
        </a>
        <span class="badge ${run.status}">${LABELS[run.status]}</span>
        ${this.#canDelete && html`<button type="button" class="small danger" data-delete="${run.id}" aria-label="Delete run of ${run.country}">✕</button>`}
      </div>`,
    );
  }
}
