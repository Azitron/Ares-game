import { html, mount } from '../../utils/html.js';
import { MapView } from '../map/MapView.js';
import { BriefView } from './BriefView.js';
import { DockView } from './DockView.js';
import { HudView } from './HudView.js';
import { LegendView } from './LegendView.js';
import { LiveTicker } from './LiveTicker.js';
import { NumberFx } from './NumberFx.js';
import { RankingView } from './RankingView.js';

export class GameView {
  #root;
  #numbers = new NumberFx();
  #ticker = new LiveTicker();
  #hud;
  #brief = new BriefView();
  #ranking;
  #dock = new DockView();
  #regions = {};
  #map = null;

  constructor(root) {
    this.#root = root;
    this.#hud = new HudView(this.#numbers);
    this.#ranking = new RankingView(this.#numbers);
  }

  get map() {
    return this.#map;
  }

  mount() {
    mount(
      this.#root,
      html`<div class="hud" id="hud" aria-live="polite"></div>
        <div class="main"><div><div class="mw" id="map-wrap"></div><div id="brief"></div>${new LegendView().render()}</div><aside class="side" id="side" aria-label="Ranking and intel feed"></aside></div>
        <div class="dock" id="dock" role="toolbar" aria-label="Game actions"></div>`,
    );
    const q = (selector) => this.#root.querySelector(selector);
    this.#regions = { hud: q('#hud'), brief: q('#brief'), side: q('#side'), dock: q('#dock') };
    this.#map = new MapView(q('#map-wrap'));
    this.#map.mount();
  }

  showMissing(message) {
    mount(this.#root, html`<section class="panel narrow"><h2>Signal lost</h2><p>${message}</p><a href="./" data-route>Back to the lobby</a></section>`);
  }

  update(vm) {
    mount(this.#regions.hud, this.#hud.render(vm));
    mount(this.#regions.brief, this.#brief.render(vm));
    mount(this.#regions.side, this.#ranking.render(vm));
    mount(this.#regions.dock, this.#dock.render(vm));
    this.#numbers.animate(this.#root);
    this.#map.draw(vm);
  }

  tick(game, population) {
    this.#ticker.update(this.#root, game, population);
  }
}
