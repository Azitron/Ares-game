import { PHASES } from '../../config/rules.js';
import { html } from '../../utils/html.js';

export class DockView {
  #button(action, icon, label, enabled, hot = false) {
    return html`<button type="button" class="bt${hot ? ' hot' : ''}" data-a="${action}" ${enabled ? '' : 'disabled'}><i>${icon}</i>${label}</button>`;
  }

  render({ game, selection, isOwner, isMyTurn, busy, fast }) {
    const striker = selection.from === null ? null : game.countries[selection.from];
    const ready = isMyTurn && !busy && game.phase === PHASES.ACT;
    const attacking = Boolean(game.attack);
    const canStrike = ready && !attacking && striker && striker.owner === 0 && striker.soldiers > 1 && selection.to !== null;
    const buttons = isOwner
      ? [
          this.#button('atk', '⚔', 'STRIKE', canStrike, true),
          this.#button('roll', '🎲', 'ROLL', ready && attacking),
          this.#button('xf', '🔁', selection.mode === 'transfer' ? 'PICK DEST' : 'TRANSFER', ready && !attacking && selection.from !== null),
          this.#button('back', attacking ? '🏳' : '⏭', attacking ? 'FALL BACK' : 'HOLD', ready),
          this.#button('ff', '⏩', fast ? 'NORMAL' : 'FAST', true),
        ]
      : [html`<div class="bt"><i>👁</i>SPECTATING</div>`];
    buttons.push(this.#button('share', '🔗', 'SHARE', true));
    if (game.isOver && game.fx?.n) buttons.push(this.#button('nuke', '☢', 'FINALE', true, true));
    return html`${buttons}`;
  }
}
