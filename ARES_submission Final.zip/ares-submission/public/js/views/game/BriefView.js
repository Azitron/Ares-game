import { OWNER_COLOURS, PHASES } from '../../config/rules.js';
import { attackEdge, diceCount } from '../../engine/Rules.js';
import { formatSigned } from '../../utils/format.js';
import { html } from '../../utils/html.js';

export class BriefView {
  render({ game, selection, isMyTurn }) {
    const striker = selection.from === null ? null : game.countries[selection.from];
    const target = selection.to === null ? null : game.countries[selection.to];
    const placing = isMyTurn && game.phase === PHASES.REINFORCE;
    const edge = striker && target ? attackEdge(striker.soldiers, target.soldiers) : 0;
    const dice = game.dice;
    return html`<div class="brief">
      ${striker || target
        ? html`<div class="vs2"><span>${striker ? `${striker.flag} ${striker.name} · ⚔ ${striker.soldiers}` : 'Pick your striker'}</span><em>VS</em><span>${target ? `${target.flag} ${target.name} · 🛡 ${target.soldiers}` : 'Pick a target'}</span></div>`
        : html`<small>Tap one of your countries, then an enemy, then hit STRIKE.</small>`}
      ${striker && target && html`<small>Dice per roll: <b>${diceCount(striker.soldiers, target.soldiers)}</b> · edge ${formatSigned(edge)} (${edge >= 1 ? 'favourable' : 'risky'})${placing ? ' · place your reinforcements first' : ''}</small>`}
      <div class="dice">${dice && html`<div class="dg">${dice.ad.map((d) => html`<span class="die" style="--c:${OWNER_COLOURS[dice.ai]}">${d}</span>`)}</div><div class="dg">${dice.dd.map((d) => html`<span class="die" style="--c:${OWNER_COLOURS[dice.di]}">${d}</span>`)}</div>`}</div>
    </div>`;
  }
}
