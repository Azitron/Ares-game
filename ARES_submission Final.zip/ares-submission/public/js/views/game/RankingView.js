import { HUMAN, OWNER_COLOURS, REQUIRED_COUNTRY } from '../../config/rules.js';
import { formatPeople } from '../../utils/format.js';
import { html } from '../../utils/html.js';

export class RankingView {
  #numbers;

  constructor(numbers) {
    this.#numbers = numbers;
  }

  render({ game, population, selection }) {
    const strongest = Math.max(1, ...game.countries.map((c) => c.soldiers));
    const rows = game.countries
      .map((country, index) => ({ country, index }))
      .sort((a, b) => b.country.soldiers - a.country.soldiers)
      .map(({ country, index }) => {
        const classes = ['rw', selection.from === index ? 'sel' : '', selection.to === index ? 'tg' : '', game.players[country.owner].alive ? '' : 'dead'].filter(Boolean).join(' ');
        return html`<div class="${classes}${this.#numbers.trend(`rank-${index}`, country.soldiers)}" data-i="${index}" style="--c:${OWNER_COLOURS[country.owner]}">
          <span class="fg">${country.flag}</span>
          <div class="rb"><b>${country.name}${country.name === REQUIRED_COUNTRY ? ' ★' : ''}</b><small>${country.owner === HUMAN ? 'YOU' : `NPC · ${game.players[country.owner].name}`}</small><div class="bar"><i style="width:${(country.soldiers / strongest) * 100}%"></i></div></div>
          <div class="rn"><b>🛡 ${this.#numbers.span(`rank-${index}`, country.soldiers, 's')}</b><small>👥 <span data-lp="${index}" data-lf="f">${formatPeople(population.current(country))}</span></small></div>
        </div>`;
      });
    const feed = [...game.log].reverse().map((entry) => html`<div style="--c:${OWNER_COLOURS[entry.i]}">${entry.t}${entry.w && html`<i>${entry.w}</i>`}</div>`);
    return html`<h3>WORLD RANKING</h3>${rows}<h3>INTEL FEED</h3><div class="log">${feed}</div>`;
  }
}
