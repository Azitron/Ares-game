import { HUMAN, PHASES, WINNER } from '../../config/rules.js';
import { AI_STATUS } from '../../ai/AiClient.js';
import { formatGameDate, formatPeople } from '../../utils/format.js';
import { html } from '../../utils/html.js';

const AI_LABELS = Object.freeze({
  [AI_STATUS.TEMPLATES]: '🤖 TEMPLATES',
  [AI_STATUS.READY]: '🤖 AI READY',
  [AI_STATUS.LIVE]: '🤖 AI LIVE',
  [AI_STATUS.OFFLINE]: '🤖 AI OFFLINE',
});

const ICONS = Object.freeze({ date: '📅', pop: '👥', sol: '🛡', ter: '🏴', draft: '📦' });

export class HudView {
  #numbers;

  constructor(numbers) {
    this.#numbers = numbers;
  }

  #status({ game, isOwner, isMyTurn }) {
    if (game.isOver) return game.winner === WINNER.HUMAN ? '🏆 YOU OWN THE WORLD' : '☠ FLATLINED';
    if (isMyTurn) return 'YOUR MOVE';
    if (!isOwner) return '👁 SPECTATING';
    return `${game.currentPlayer.name.toUpperCase()} ACTING…`;
  }

  #chip(key, label, value, content) {
    return html`<div class="chip${this.#numbers.trend(key, value)}"><i class="ci">${ICONS[key]}</i><div class="cv"><small>${label}</small><b>${content}</b></div></div>`;
  }

  render(vm) {
    const { game, population, aiStatus, isMyTurn } = vm;
    const mine = game.countriesOf(HUMAN);
    const soldiers = mine.reduce((sum, c) => sum + c.soldiers, 0);
    const placing = isMyTurn && game.phase === PHASES.REINFORCE;
    const last = game.log.length ? game.log[game.log.length - 1] : null;
    return html`<div class="me"><span class="fg">${game.countries[HUMAN].flag}</span><div><b>${game.players[HUMAN].name}</b><small>YOUR NATION</small></div></div>
      ${this.#chip('date', 'DATE', 0, html`<span id="game-date">${formatGameDate(population.gameTime())}</span>`)}
      ${this.#chip('pop', 'POPULATION', 0, html`<span data-lp="me" data-lf="f">${formatPeople(population.total(mine))}</span>`)}
      ${this.#chip('sol', 'SOLDIERS', soldiers, this.#numbers.span('hud-soldiers', soldiers, 's'))}
      ${this.#chip('ter', 'TERRITORIES', mine.length, `${mine.length}/10`)}
      ${this.#chip('draft', placing ? 'PLACE NOW' : 'NEXT DRAFT', placing ? game.pool : mine.length, placing ? game.pool : `+${2 * mine.length}`)}
      <div class="news"><b>NEWS ▸</b> ${last ? last.t : 'The grid awaits…'}</div>
      <div class="pill">${this.#status(vm)}</div>
      <div class="pill">RND ${game.round}</div>
      <div class="pill" id="ai-pill">${AI_LABELS[aiStatus]}</div>`;
  }
}
