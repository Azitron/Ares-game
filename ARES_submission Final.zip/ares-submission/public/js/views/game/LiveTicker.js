import { HUMAN } from '../../config/rules.js';
import { formatGameDate, formatMillions, formatPeople } from '../../utils/format.js';

export class LiveTicker {
  update(root, game, population) {
    root.querySelectorAll('[data-lp]').forEach((element) => {
      const key = element.dataset.lp;
      const millions = key === 'me'
        ? population.total(game.countriesOf(HUMAN))
        : population.current(game.countries[Number(key)]);
      element.textContent = element.dataset.lf === 'c' ? formatMillions(millions) : formatPeople(millions);
    });
    const date = root.querySelector('#game-date');
    if (date) date.textContent = formatGameDate(population.gameTime());
  }
}
