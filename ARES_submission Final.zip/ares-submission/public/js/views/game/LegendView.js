import { SOLDIER_TIERS } from '../../config/rules.js';
import { html } from '../../utils/html.js';

export class LegendView {
  render() {
    return html`<details class="leg" open><summary>POPULATION → SOLDIERS</summary>
      <div class="lg">${SOLDIER_TIERS.map((limit, i) => html`<span>≤${limit}M<b>${i + 1}</b></span>`)}<span>&gt;150M<b>9</b></span></div>
      <small>You start with your country's base soldiers. Conquering a country grants max(2, ⌊base ÷ 2⌋). From round 2 you get +2 soldiers for every country you hold, every turn. Drafting soldiers shrinks a country's population (0.5% per soldier), losing soldiers in battle shrinks it more (1% each), populations grow live in real time (1 second = 1 game day), and a conquered country loses 3% of its people.</small>
    </details>`;
  }
}
