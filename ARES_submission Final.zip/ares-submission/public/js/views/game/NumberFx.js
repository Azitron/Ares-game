import { html } from '../../utils/html.js';
import { formatMillions } from '../../utils/format.js';

const TWEEN_MS = 650;

export class NumberFx {
  #previousTrend = new Map();
  #previousShown = new Map();

  trend(key, value) {
    const before = this.#previousTrend.get(key);
    this.#previousTrend.set(key, value);
    if (before === undefined || before === value) return '';
    return value > before ? ' up' : ' dn';
  }

  span(key, value, kind) {
    const shown = kind === 'p' ? formatMillions(value) : Math.round(value);
    return html`<span class="nv" data-k="${key}" data-v="${value}" data-f="${kind}">${shown}</span>`;
  }

  animate(root, frame = (fn) => requestAnimationFrame(fn), now = () => performance.now()) {
    root.querySelectorAll('.nv').forEach((element) => {
      const key = element.dataset.k;
      const target = Number(element.dataset.v);
      const kind = element.dataset.f;
      const show = (n) => (kind === 'p' ? formatMillions(n) : Math.round(n).toLocaleString('en'));
      const from = this.#previousShown.has(key) ? this.#previousShown.get(key) : target;
      this.#previousShown.set(key, target);
      if (from === target) return;
      const start = now();
      const step = (time) => {
        const progress = Math.min(1, (time - start) / TWEEN_MS);
        element.textContent = show(from + (target - from) * progress);
        if (progress < 1 && element.isConnected) frame(step);
      };
      frame(step);
    });
  }
}
