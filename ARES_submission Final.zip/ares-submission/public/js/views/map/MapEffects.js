import { MAP_HEIGHT, MAP_WIDTH } from './NodeLayout.js';
import { formatCompactPeople } from '../../utils/format.js';
import { OWNER_COLOURS } from '../../config/rules.js';
import { html, mount } from '../../utils/html.js';

const FX_WINDOW_MS = 4000;

const curve = (from, to) => {
  const mid = [(from[0] + to[0]) / 2, (from[1] + to[1]) / 2 - Math.hypot(from[0] - to[0], from[1] - to[1]) * 0.28];
  return { mid, path: `M${from} Q${mid} ${to}` };
};

export class MapEffects {
  #arcs;
  #boom;
  #map;
  #lastFx = 0;
  #now;
  #frame;

  constructor({ arcs, boom, map, now = () => Date.now(), frame = (fn) => requestAnimationFrame(fn) }) {
    this.#arcs = arcs;
    this.#boom = boom;
    this.#map = map;
    this.#now = now;
    this.#frame = frame;
  }

  reset() {
    this.#lastFx = 0;
  }

  clearBoom() {
    mount(this.#boom, '');
  }

  aimPath(from, to) {
    return curve(from, to).path;
  }

  play(game, positions) {
    const fx = game.fx;
    if (!fx || fx.k === this.#lastFx || this.#now() - fx.k >= FX_WINDOW_MS) return;
    this.#lastFx = fx.k;
    const from = positions[fx.f];
    const to = positions[fx.t];
    const { mid, path } = curve(from, to);
    const colour = fx.n ? '#f9f002' : OWNER_COLOURS[game.countries[fx.f].owner];
    const id = fx.k;
    mount(this.#arcs, html`<path class="arc" d="${path}" stroke="${colour}" filter="url(#glow)"/><g color="${colour}" filter="url(#glow)"><use href="#${fx.n ? 'bomb' : 'missile'}" transform="scale(${fx.n ? 1.5 : 1.7})"/></g>`);
    this.#fly(this.#arcs.querySelector('g'), from, mid, to, fx.n ? 2.4 : 0.8, () => this.#impact(fx, from, to, colour, id));
  }

  #impact(fx, from, to, colour, id) {
    if (this.#lastFx !== id) return;
    this.#arcs.querySelector('g')?.remove();
    this.#arcs.insertAdjacentHTML(
      'beforeend',
      String(html`<circle cx="${to[0]}" cy="${to[1]}" r="4" class="hit" stroke="${colour}"/>
        ${fx.dl ? html`<text x="${to[0]}" y="${to[1] - 18}" text-anchor="middle" class="pf" fill="#ff2a6d">−${fx.dl}</text>` : ''}
        ${fx.al ? html`<text x="${from[0]}" y="${from[1] - 18}" text-anchor="middle" class="pf" fill="#f9f002">−${fx.al}</text>` : ''}
        ${fx.pb ? html`<text x="${to[0]}" y="${to[1] - 4}" text-anchor="middle" class="pf small" fill="#fff">−${formatCompactPeople(fx.pb)} 👥</text>` : ''}
        ${fx.pa ? html`<text x="${from[0]}" y="${from[1] - 4}" text-anchor="middle" class="pf small" fill="#fff">−${formatCompactPeople(fx.pa)} 👥</text>` : ''}`),
    );
    if (fx.n) this.#detonate(fx.v, to[0], to[1]);
    else setTimeout(() => this.#lastFx === id && mount(this.#arcs, ''), 1300);
  }

  #detonate(victory, x, y) {
    const colour = victory ? '#f9f002' : '#ff2a6d';
    this.#map.classList.remove('shk');
    void this.#map.getBoundingClientRect();
    this.#map.classList.add('shk');
    mount(
      this.#boom,
      html`<rect width="${MAP_WIDTH}" height="${MAP_HEIGHT}" class="bf"/><rect width="${MAP_WIDTH}" height="${MAP_HEIGHT}" class="bk"/>
        <circle cx="${x}" cy="${y}" r="14" class="sw"/><circle cx="${x}" cy="${y}" r="14" class="sw" style="animation-delay:.3s"/><circle cx="${x}" cy="${y}" r="14" class="sw" style="animation-delay:.6s"/>
        <g class="hz" filter="url(#glow)" transform="translate(${MAP_WIDTH / 2 - 150},${MAP_HEIGHT / 2 - 200}) scale(1.5)" style="color:${colour}"><use href="#hazard"/></g>
        <text x="${MAP_WIDTH / 2}" y="${MAP_HEIGHT - 58}" text-anchor="middle" class="vt" fill="${colour}" filter="url(#glow)">${victory ? 'VICTORY' : 'DEFEAT'}</text>
        <text x="${MAP_WIDTH / 2}" y="${MAP_HEIGHT - 30}" text-anchor="middle" class="vs">click anywhere to close</text>`,
    );
  }

  #fly(element, a, m, b, seconds, done) {
    const start = performance.now();
    const step = (time) => {
      const u = Math.min(1, (time - start) / (seconds * 1000));
      const e = u * (0.35 + 0.65 * u);
      const r = 1 - e;
      const x = r * r * a[0] + 2 * r * e * m[0] + e * e * b[0];
      const y = r * r * a[1] + 2 * r * e * m[1] + e * e * b[1];
      const angle = Math.atan2(2 * r * (m[1] - a[1]) + 2 * e * (b[1] - m[1]), 2 * r * (m[0] - a[0]) + 2 * e * (b[0] - m[0]));
      element.setAttribute('transform', `translate(${x},${y}) rotate(${(angle * 180) / Math.PI})`);
      if (u < 1) this.#frame(step);
      else done();
    };
    this.#frame(step);
  }
}
