const BLADE = 'M57,25.52 A86,86 0 0 1 143,25.52 L113,77.48 A26,26 0 0 0 87,77.48Z';

export const SVG_DEFS = `
<filter id="glow" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
<g id="missile">
  <path d="M12,0 L5,-3.2 L-8,-3.2 L-8,3.2 L5,3.2Z" fill="currentColor"/>
  <path d="M12,0 L5,-3.2 L-8,-3.2 L-8,3.2 L5,3.2Z" fill="none" stroke="#05d9e8" stroke-width=".7" transform="translate(-1.6,1.2)"/>
  <path d="M-3,-3.2 L-9,-8 L-10,-3.2Z M-3,3.2 L-9,8 L-10,3.2Z" fill="#ff2a6d"/>
  <path d="M-8,-1H6M-8,1H6" stroke="#07060d" stroke-width=".7"/>
  <path d="M12,0 L5,-3.2 L5,3.2Z" fill="#fff"/>
  <path class="flame" d="M-8,0 L-21,-3 L-16,0 L-21,3Z" fill="#f9f002"/>
</g>
<g id="bomb">
  <path d="M20,0 C16,-9 6,-9 0,-8 L-16,-8 L-16,8 L0,8 C6,9 16,9 20,0Z" fill="currentColor"/>
  <path d="M4,-8.6 H9 V8.6 H4Z M-7,-8 H-2 V8 H-7Z" fill="#07060d"/>
  <path d="M-10,-8 L-21,-18 L-16,-8Z M-10,8 L-21,18 L-16,8Z" fill="#ff2a6d"/>
  <path class="flame" d="M-16,0 L-36,-7 L-29,0 L-36,7Z" fill="#ff9a3c"/>
</g>
<g id="hazard" fill="currentColor">
  <path d="${BLADE}"/>
  <path d="${BLADE}" transform="rotate(120 100 100)"/>
  <path d="${BLADE}" transform="rotate(240 100 100)"/>
  <circle cx="100" cy="100" r="14"/>
</g>`;
