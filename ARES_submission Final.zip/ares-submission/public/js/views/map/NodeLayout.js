import { findCountry } from '../../data/countries.js';

export const MAP_WIDTH = 1000;
export const MAP_HEIGHT = 520;

const SPACING = { x: 84, y: 88 };
const BOUNDS = { left: 46, right: MAP_WIDTH - 46, top: 40, bottom: MAP_HEIGHT - 56 };

export class NodeLayout {
  #project = (lon, lat) => [((lon + 180) / 360) * MAP_WIDTH, ((90 - lat) / 180) * MAP_HEIGHT];

  useProjection(project) {
    this.#project = project;
  }

  project(lon, lat) {
    return this.#project(lon, lat);
  }

  compute(countries) {
    const origins = countries.map((country) => {
      const entry = findCountry(country.name);
      return this.#project(entry?.lon ?? 0, entry?.lat ?? 0).slice();
    });
    const positions = origins.map((point) => point.slice());
    for (let iteration = 0; iteration < 120; iteration += 1) {
      let moved = 0;
      for (let i = 0; i < positions.length; i += 1) {
        for (let j = i + 1; j < positions.length; j += 1) {
          moved += this.#separate(positions[i], positions[j]);
        }
      }
      positions.forEach((point) => {
        point[0] = Math.max(BOUNDS.left, Math.min(BOUNDS.right, point[0]));
        point[1] = Math.max(BOUNDS.top, Math.min(BOUNDS.bottom, point[1]));
      });
      if (!moved) break;
    }
    return { positions, origins };
  }

  #separate(a, b) {
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const distance = Math.hypot(dx / SPACING.x, dy / SPACING.y);
    if (distance >= 1) return 0;
    const ux = distance ? dx : 1;
    const uy = distance ? dy : 0.3;
    const length = Math.hypot(ux, uy) || 1;
    const push = ((1 - distance) / 2) * 0.6;
    a[0] -= (ux / length) * push * SPACING.x;
    a[1] -= (uy / length) * push * SPACING.y;
    b[0] += (ux / length) * push * SPACING.x;
    b[1] += (uy / length) * push * SPACING.y;
    return 1;
  }
}
