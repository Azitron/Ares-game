import { OWNER_COLOURS, REQUIRED_COUNTRY } from '../../config/rules.js';
import { findCountry } from '../../data/countries.js';
import { formatMillions } from '../../utils/format.js';
import { html, mount, raw } from '../../utils/html.js';
import { MapEffects } from './MapEffects.js';
import { MAP_HEIGHT, MAP_WIDTH, NodeLayout } from './NodeLayout.js';
import { SVG_DEFS } from './svgDefs.js';

const gridPath = () => {
  const verticals = Array.from({ length: 19 }, (_, i) => `M${(i * MAP_WIDTH) / 18},0V${MAP_HEIGHT}`);
  const horizontals = Array.from({ length: 10 }, (_, i) => `M0,${(i * MAP_HEIGHT) / 9}H${MAP_WIDTH}`);
  return [...verticals, ...horizontals].join('');
};

export class MapView {
  #root;
  #layout = new NodeLayout();
  #effects = null;
  #landPaths = new Map();
  #layers = {};

  constructor(root) {
    this.#root = root;
  }

  mount() {
    mount(
      this.#root,
      html`<svg id="map" class="map" viewBox="0 0 ${MAP_WIDTH} ${MAP_HEIGHT}" role="img" aria-label="World map showing the ten countries in play">
        <defs>${raw(SVG_DEFS)}</defs>
        <g id="land"><path class="gr" d="${gridPath()}"/></g><g id="lock"></g><g id="arcs"></g><g id="nodes"></g><g id="boom"></g>
      </svg>`,
    );
    const q = (selector) => this.#root.querySelector(selector);
    this.#layers = { land: q('#land'), lock: q('#lock'), nodes: q('#nodes') };
    this.#effects = new MapEffects({ arcs: q('#arcs'), boom: q('#boom'), map: q('#map') });
  }

  get effects() {
    return this.#effects;
  }

  async loadAtlas(url, globals = globalThis) {
    const { d3, topojson } = globals;
    if (!d3 || !topojson) return false;
    try {
      const projection = d3.geoNaturalEarth1().fitExtent([[8, 8], [MAP_WIDTH - 8, MAP_HEIGHT - 8]], { type: 'Sphere' });
      this.#layout.useProjection((lon, lat) => projection([lon, lat]));
      const atlas = await (await fetch(url)).json();
      const path = d3.geoPath(projection);
      const features = topojson.feature(atlas, atlas.objects.countries).features;
      const land = features.map((feature) => html`<path data-n="${feature.properties.name}" d="${path(feature)}"/>`);
      mount(this.#layers.land, html`<path d="${path({ type: 'Sphere' })}" class="ocean"/>${land}`);
      this.#landPaths = new Map(
        [...this.#layers.land.querySelectorAll('path[data-n]')].map((element) => [element.dataset.n, element]),
      );
      return true;
    } catch (error) {
      return false;
    }
  }

  centreOn(game) {
    const [x] = this.#layout.compute(game.countries).positions[0];
    if (this.#root.scrollWidth > this.#root.clientWidth) {
      this.#root.scrollLeft = (x / MAP_WIDTH) * this.#root.scrollWidth - this.#root.clientWidth / 2;
    }
  }

  draw({ game, population, selection }) {
    if (!this.#layers.nodes) return;
    const { positions, origins } = this.#layout.compute(game.countries);
    this.#paintLand(game);
    const leaders = game.countries.map((_, i) => {
      const [ox, oy] = origins[i];
      const [px, py] = positions[i];
      return Math.hypot(ox - px, oy - py) > 10
        ? html`<line class="tl" x1="${ox}" y1="${oy}" x2="${px}" y2="${py}"/><circle class="td" cx="${ox}" cy="${oy}" r="3"/>`
        : '';
    });
    const nodes = game.countries.map((country, i) => this.#node(game, country, i, positions[i], population, selection));
    mount(this.#layers.nodes, html`${leaders}${nodes}`);
    const from = game.attack ? game.attack.f : selection.from;
    const to = game.attack ? game.attack.t : selection.to;
    mount(this.#layers.lock, from !== null && to !== null ? html`<path class="aim" d="${this.#effects.aimPath(positions[from], positions[to])}"/>` : '');
    this.#effects.play(game, positions);
  }

  #paintLand(game) {
    this.#landPaths.forEach((element) => element.removeAttribute('style'));
    game.countries.forEach((country) => {
      const mapName = findCountry(country.name)?.mapName ?? country.name;
      this.#landPaths.get(mapName)?.setAttribute('style', `fill:${OWNER_COLOURS[country.owner]};fill-opacity:.9;stroke:#fff;stroke-width:1.2`);
    });
  }

  #node(game, country, index, [x, y], population, selection) {
    const colour = OWNER_COLOURS[country.owner];
    const home = country.name === REQUIRED_COUNTRY;
    const dead = game.players[country.owner].alive ? '' : ' dead';
    return html`<g class="nd${dead}" data-i="${index}" transform="translate(${x},${y})" tabindex="0" role="button" aria-label="${country.name}, ${country.soldiers} soldiers">
      ${selection.from === index && html`<circle r="26" class="rs"/>`}
      ${selection.to === index && html`<circle r="26" class="rt"/>`}
      ${home && html`<circle r="23" class="home"/>`}
      <circle r="17" fill="${colour}" stroke="#fff" stroke-width="3"/>
      <text y="6" text-anchor="middle" class="flag">${country.flag}</text>
      <circle cx="-6" cy="-6" r="4.2" fill="#fff"/><circle cx="6" cy="-6" r="4.2" fill="#fff"/><circle cx="-5" cy="-5.5" r="2" fill="#111"/><circle cx="7" cy="-5.5" r="2" fill="#111"/>
      <g transform="translate(0,30)"><rect x="-26" y="-9" width="52" height="17" rx="8.5" fill="#10204a" stroke="${colour}" stroke-width="2"/><text y="4" text-anchor="middle" class="ns" fill="#fff">🛡 ${country.soldiers}</text></g>
      <text y="-24" text-anchor="middle" class="nl">${country.name}${home ? ' ★' : ''}</text>
      <text y="48" text-anchor="middle" class="nl tiny">👥 <tspan data-lp="${index}" data-lf="c">${formatMillions(population.current(country))}</tspan></text>
    </g>`;
  }
}
