import { SOLDIER_TIERS } from '../config/rules.js';
import { html } from '../utils/html.js';

export class HowToPlayView {
  render() {
    return html`<h2>How to play</h2>
      <ol class="howto">
        <li><b>Goal:</b> conquer all 10 countries on the grid. You are Player 1; nine NPC rivals play after you. South Africa is always in the game.</li>
        <li><b>Your turn:</b> tap one of your countries (gold ring), tap an enemy (red ring), press <b>STRIKE</b>, then <b>ROLL</b> as often as you like. <b>FALL BACK</b> or <b>HOLD</b> ends your turn.</li>
        <li><b>Dice:</b> the attacker rolls (soldiers - 1) dice and the defender rolls up to its soldier count. The higher die of each pair kills one soldier. Ties kill nobody.</li>
        <li><b>Conquest:</b> when a defender hits 0 soldiers you capture it and it gets max(2, half its base soldiers). You may then move spare troops in.</li>
        <li><b>Reinforcements:</b> from round 2 you get +2 soldiers per country you hold. Tap your countries to place them (hold Shift to place all at once).</li>
        <li><b>Transfer:</b> when no attack is running, press TRANSFER, then tap a destination to move soldiers between your countries. Each country keeps 1 soldier.</li>
        <li><b>Soldiers from population:</b> ${SOLDIER_TIERS.map((limit, i) => html`up to ${limit}M = ${i + 1}; `)}above 150M = 9.</li>
        <li><b>Live population:</b> populations grow in real time. Drafting, losses and conquests shrink them.</li>
        <li><b>Spectators</b> can watch any run from its link. Only the owner can play.</li>
        <li><b>FAST</b> speeds up NPC turns. The header pill shows whether OpenAI commentary is live.</li>
      </ol>
      <div class="row"><button type="button" class="hot" data-act="close">Got it</button></div>`;
  }
}
