import { html } from '../utils/html.js';

export class LoginView {
  render({ mode = 'signin', error = '' }) {
    const register = mode === 'register';
    return html`<section class="panel narrow" aria-labelledby="auth-title">
      <h2 id="auth-title">Jack in to the war grid</h2>
      <p>Anyone can watch a run. Only signed-in operators can move pieces.</p>
      <div class="tabs" role="tablist">
        <button type="button" role="tab" class="tab ${register ? '' : 'on'}" aria-selected="${String(!register)}" data-mode="signin">Sign in</button>
        <button type="button" role="tab" class="tab ${register ? 'on' : ''}" aria-selected="${String(register)}" data-mode="register">Create account</button>
      </div>
      <form id="auth-form" novalidate>
        ${register && html`<label for="callsign">Callsign</label><input id="callsign" name="callsign" autocomplete="nickname" maxlength="20" placeholder="3-20 letters, numbers, - or _">`}
        <label for="email">Email</label>
        <input id="email" name="email" type="email" autocomplete="email" maxlength="120" placeholder="you@example.com">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="${register ? 'new-password' : 'current-password'}" maxlength="64" placeholder="${register ? '8+ characters, letters and numbers' : 'Your password'}">
        <button type="submit" class="hot">${register ? 'Create account' : 'Jack in'}</button>
      </form>
      <p class="form-error" id="auth-error" role="alert">${error}</p>
    </section>`;
  }
}
