import { html, mount } from '../utils/html.js';

export class Modal {
  #document;
  #element = null;
  #onKey = null;

  constructor(document) {
    this.#document = document;
  }

  open(content, { label = 'Dialog', onDismiss = null } = {}) {
    this.close();
    const element = this.#document.createElement('div');
    element.className = 'modal';
    mount(element, html`<div class="panel dialog" role="dialog" aria-modal="true" aria-label="${label}">${content}</div>`);
    this.#document.body.append(element);
    this.#element = element;
    if (onDismiss) {
      this.#onKey = (event) => {
        if (event.key === 'Escape') onDismiss();
      };
      this.#document.addEventListener('keydown', this.#onKey);
    }
    element.querySelector('button, input')?.focus();
    return element;
  }

  close() {
    if (this.#onKey) this.#document.removeEventListener('keydown', this.#onKey);
    this.#onKey = null;
    this.#element?.remove();
    this.#element = null;
  }
}
