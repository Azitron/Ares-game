import { html } from '../utils/html.js';

export class CountPrompt {
  #modal;

  constructor(modal) {
    this.#modal = modal;
  }

  askCount(message, max) {
    return new Promise((resolve) => {
      const half = Math.floor(max / 2);
      const finish = (value) => {
        this.#modal.close();
        resolve(value);
      };
      const element = this.#modal.open(
        html`<b>${message}</b>
          <label class="sr-only" for="count-range">Amount</label>
          <input type="range" id="count-range" min="0" max="${max}" value="${half}">
          <output id="count-out" for="count-range">${half}</output>
          <div class="row"><button type="button" class="hot" data-act="confirm">Lock it in</button><button type="button" data-act="cancel">Skip</button></div>`,
        { label: message, onDismiss: () => finish(0) },
      );
      const range = element.querySelector('#count-range');
      const out = element.querySelector('#count-out');
      range.addEventListener('input', () => {
        out.value = range.value;
      });
      element.querySelector('[data-act="confirm"]').addEventListener('click', () => finish(Number(range.value)));
      element.querySelector('[data-act="cancel"]').addEventListener('click', () => finish(0));
    });
  }
}
