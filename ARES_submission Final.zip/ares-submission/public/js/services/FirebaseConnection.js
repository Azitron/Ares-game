export class FirebaseConnection {
  #sdk;
  #app;
  #auth;
  #db;

  constructor({ sdk, config }) {
    this.#sdk = sdk;
    this.#app = sdk.initializeApp(config);
    this.#auth = sdk.getAuth(this.#app);
    this.#db = sdk.getFirestore(this.#app);
  }

  get sdk() {
    return this.#sdk;
  }

  get auth() {
    return this.#auth;
  }

  get db() {
    return this.#db;
  }
}
