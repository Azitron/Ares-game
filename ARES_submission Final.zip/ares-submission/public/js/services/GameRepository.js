import { Game } from '../models/Game.js';
import { GameSummary } from '../models/GameSummary.js';
import { assertGameDocument, validateGameId } from '../utils/validation.js';

const COLLECTION = 'games';

export class GameRepository {
  #sdk;
  #db;

  constructor({ sdk, db }) {
    this.#sdk = sdk;
    this.#db = db;
  }

  newId() {
    return this.#sdk.doc(this.#sdk.collection(this.#db, COLLECTION)).id;
  }

  #ref(id) {
    return this.#sdk.doc(this.#db, COLLECTION, validateGameId(id));
  }

  async save(game) {
    const document = assertGameDocument(game.toJSON());
    await this.#sdk.setDoc(this.#ref(document.id), document);
  }

  async load(id) {
    const snapshot = await this.#sdk.getDoc(this.#ref(id));
    return snapshot.exists() ? Game.fromJSON(snapshot.data()) : null;
  }

  subscribe(id, onGame, onError) {
    return this.#sdk.onSnapshot(
      this.#ref(id),
      (snapshot) => onGame(snapshot.exists() ? Game.fromJSON(snapshot.data()) : null),
      onError,
    );
  }

  async listByOwner(uid) {
    const q = this.#sdk.query(this.#sdk.collection(this.#db, COLLECTION), this.#sdk.where('owner', '==', uid));
    const snapshot = await this.#sdk.getDocs(q);
    return snapshot.docs.map((d) => GameSummary.fromDocument(d.data())).sort(GameSummary.compare);
  }

  async listPublic(max) {
    const q = this.#sdk.query(
      this.#sdk.collection(this.#db, COLLECTION),
      this.#sdk.orderBy('created', 'desc'),
      this.#sdk.limit(max),
    );
    const snapshot = await this.#sdk.getDocs(q);
    return snapshot.docs.map((d) => GameSummary.fromDocument(d.data()));
  }

  remove(id) {
    return this.#sdk.deleteDoc(this.#ref(id));
  }
}
