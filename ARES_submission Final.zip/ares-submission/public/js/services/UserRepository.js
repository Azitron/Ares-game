import { validateCallsign } from '../utils/validation.js';

const COLLECTION = 'users';

export class UserRepository {
  #sdk;
  #db;
  #clock;

  constructor({ sdk, db, clock }) {
    this.#sdk = sdk;
    this.#db = db;
    this.#clock = clock;
  }

  async ensureProfile(user) {
    const ref = this.#sdk.doc(this.#db, COLLECTION, user.uid);
    const existing = await this.#sdk.getDoc(ref);
    if (existing.exists()) return existing.data();
    const profile = { callsign: validateCallsign(user.callsign), created: this.#clock.now() };
    await this.#sdk.setDoc(ref, profile);
    return profile;
  }
}
