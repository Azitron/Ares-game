import { SessionUser } from '../models/SessionUser.js';
import { validateCallsign, validateEmail, validateLoginPassword, validateNewPassword } from '../utils/validation.js';

export class AuthService {
  #sdk;
  #auth;
  #listeners = new Set();

  constructor({ sdk, auth }) {
    this.#sdk = sdk;
    this.#auth = auth;
  }

  #emit() {
    const user = this.user;
    this.#listeners.forEach((listener) => listener(user));
  }

  get user() {
    return SessionUser.fromFirebase(this.#auth.currentUser);
  }

  onChange(listener) {
    this.#listeners.add(listener);
    const stop = this.#sdk.onAuthStateChanged(this.#auth, () => this.#emit());
    return () => {
      this.#listeners.delete(listener);
      stop();
    };
  }

  async token() {
    const current = this.#auth.currentUser;
    return current ? current.getIdToken() : null;
  }

  async signIn({ email, password }) {
    const cleanEmail = validateEmail(email);
    const cleanPassword = validateLoginPassword(password);
    await this.#sdk.signInWithEmailAndPassword(this.#auth, cleanEmail, cleanPassword);
    return this.user;
  }

  async register({ callsign, email, password }) {
    const cleanCallsign = validateCallsign(callsign);
    const cleanEmail = validateEmail(email);
    const cleanPassword = validateNewPassword(password);
    const credential = await this.#sdk.createUserWithEmailAndPassword(this.#auth, cleanEmail, cleanPassword);
    await this.#sdk.updateProfile(credential.user, { displayName: cleanCallsign });
    this.#emit();
    return this.user;
  }

  signOut() {
    return this.#sdk.signOut(this.#auth);
  }
}
