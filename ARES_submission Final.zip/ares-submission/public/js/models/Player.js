export class Player {
  #name;
  #alive;
  #played;

  constructor({ name, alive = true, played = 0 }) {
    this.#name = name;
    this.#alive = alive;
    this.#played = played;
  }

  get name() {
    return this.#name;
  }

  get alive() {
    return this.#alive;
  }

  get played() {
    return this.#played;
  }

  finishTurn() {
    this.#played += 1;
  }

  eliminate() {
    this.#alive = false;
  }

  toJSON() {
    return { name: this.#name, alive: this.#alive, played: this.#played };
  }

  static fromJSON(data) {
    return new Player(data);
  }
}
