import { BOARD_SIZE } from '../config/rules.js';
import { RuleError } from '../utils/errors.js';

const assertCount = (value, label) => {
  if (!Number.isInteger(value) || value < 0) throw new RuleError(`${label} must be a whole number, 0 or more.`);
};

export class Country {
  #name;
  #flag;
  #base;
  #soldiers;
  #owner;
  #population;
  #stamp;

  constructor({ name, flag, base, soldiers = base, owner, population, stamp }) {
    if (typeof name !== 'string' || !name) throw new RuleError('A country needs a name.');
    assertCount(base, 'Base soldiers');
    assertCount(soldiers, 'Soldiers');
    assertCount(owner, 'Owner');
    if (owner >= BOARD_SIZE) throw new RuleError('Owner is out of range.');
    if (!Number.isFinite(population) || population < 0) throw new RuleError('Population must be a positive number.');
    this.#name = name;
    this.#flag = flag ?? '';
    this.#base = base;
    this.#soldiers = soldiers;
    this.#owner = owner;
    this.#population = population;
    this.#stamp = stamp;
  }

  get name() {
    return this.#name;
  }

  get flag() {
    return this.#flag;
  }

  get base() {
    return this.#base;
  }

  get soldiers() {
    return this.#soldiers;
  }

  get owner() {
    return this.#owner;
  }

  get population() {
    return this.#population;
  }

  get stamp() {
    return this.#stamp;
  }

  addSoldiers(count) {
    assertCount(count, 'Soldier count');
    this.#soldiers += count;
  }

  removeSoldiers(count) {
    assertCount(count, 'Soldier count');
    this.#soldiers = Math.max(0, this.#soldiers - count);
  }

  capture(owner, garrison) {
    assertCount(owner, 'Owner');
    assertCount(garrison, 'Garrison');
    this.#owner = owner;
    this.#soldiers = garrison;
  }

  setPopulation(value, stamp) {
    if (!Number.isFinite(value) || value < 0) throw new RuleError('Population must be a positive number.');
    this.#population = value;
    this.#stamp = stamp;
  }

  toJSON() {
    return {
      name: this.#name,
      flag: this.#flag,
      base: this.#base,
      soldiers: this.#soldiers,
      owner: this.#owner,
      pop: this.#population,
      pt: this.#stamp,
    };
  }

  static fromJSON(data) {
    return new Country({
      name: data.name,
      flag: data.flag,
      base: data.base,
      soldiers: data.soldiers,
      owner: data.owner,
      population: data.pop,
      stamp: data.pt,
    });
  }
}
