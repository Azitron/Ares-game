import { BOARD_SIZE, MAX_LOG_ENTRIES, PHASES, REINFORCE_PER_COUNTRY } from '../config/rules.js';
import { RuleError } from '../utils/errors.js';
import { Country } from './Country.js';
import { Player } from './Player.js';

export class Game {
  #id;
  #ownerUid;
  #ownerName;
  #created;
  #countries;
  #players;
  #turn;
  #round;
  #pool;
  #phase;
  #attack;
  #dice;
  #winner;
  #end;
  #fx;
  #log;

  constructor({ id, ownerUid, ownerName, created, countries, players, turn = 0, round = 1, pool = 0, phase = PHASES.ACT, attack = null, dice = null, winner = null, end = null, fx = null, log = [] }) {
    if (countries.length !== BOARD_SIZE || players.length !== BOARD_SIZE) throw new RuleError('A game needs exactly 10 countries and 10 players.');
    this.#id = id;
    this.#ownerUid = ownerUid;
    this.#ownerName = ownerName;
    this.#created = created;
    this.#countries = countries;
    this.#players = players;
    this.#turn = turn;
    this.#round = round;
    this.#pool = pool;
    this.#phase = phase;
    this.#attack = attack;
    this.#dice = dice;
    this.#winner = winner;
    this.#end = end;
    this.#fx = fx;
    this.#log = log;
  }

  get id() {
    return this.#id;
  }

  get ownerUid() {
    return this.#ownerUid;
  }

  get ownerName() {
    return this.#ownerName;
  }

  get created() {
    return this.#created;
  }

  get countries() {
    return this.#countries;
  }

  get players() {
    return this.#players;
  }

  get turn() {
    return this.#turn;
  }

  get round() {
    return this.#round;
  }

  get pool() {
    return this.#pool;
  }

  get phase() {
    return this.#phase;
  }

  get attack() {
    return this.#attack;
  }

  get dice() {
    return this.#dice;
  }

  get winner() {
    return this.#winner;
  }

  get end() {
    return this.#end;
  }

  get fx() {
    return this.#fx;
  }

  get log() {
    return this.#log;
  }

  get isOver() {
    return this.#winner !== null;
  }

  get currentPlayer() {
    return this.#players[this.#turn];
  }

  countriesOf(owner) {
    return this.#countries.filter((country) => country.owner === owner);
  }

  indexOf(country) {
    return this.#countries.indexOf(country);
  }

  alivePlayers() {
    return this.#players.filter((player) => player.alive);
  }

  beginAttack(from, to) {
    this.#attack = { f: from, t: to };
  }

  clearAttack() {
    this.#attack = null;
  }

  setPool(pool) {
    this.#pool = pool;
  }

  setPhase(phase) {
    this.#phase = phase;
  }

  recordRoll(dice, fx) {
    this.#dice = dice;
    this.#fx = fx;
  }

  replayFx(now) {
    if (this.#fx) this.#fx = { ...this.#fx, k: now };
  }

  appendLog(entry) {
    this.#log.push(entry);
    if (this.#log.length > MAX_LOG_ENTRIES) this.#log.shift();
  }

  advanceTurn() {
    this.#players[this.#turn].finishTurn();
    for (let step = 0; step < BOARD_SIZE; step += 1) {
      this.#turn = (this.#turn + 1) % BOARD_SIZE;
      if (this.#players[this.#turn].alive) break;
    }
    const owned = this.countriesOf(this.#turn).length;
    this.#pool = this.#players[this.#turn].played > 0 ? REINFORCE_PER_COUNTRY * owned : 0;
    this.#phase = this.#pool ? PHASES.REINFORCE : PHASES.ACT;
    this.#attack = null;
    this.#round = Math.max(...this.#players.map((player) => player.played)) + 1;
  }

  declareWinner(winner, now) {
    this.#winner = winner;
    this.#end = now;
  }

  toJSON() {
    return {
      id: this.#id,
      owner: this.#ownerUid,
      ownerName: this.#ownerName,
      created: this.#created,
      turn: this.#turn,
      round: this.#round,
      pool: this.#pool,
      phase: this.#phase,
      attack: this.#attack,
      dice: this.#dice,
      winner: this.#winner,
      end: this.#end,
      fx: this.#fx,
      log: this.#log,
      players: this.#players.map((player) => player.toJSON()),
      countries: this.#countries.map((country) => country.toJSON()),
    };
  }

  static fromJSON(data) {
    return new Game({
      id: data.id,
      ownerUid: data.owner,
      ownerName: data.ownerName,
      created: data.created,
      countries: data.countries.map((c) => Country.fromJSON(c)),
      players: data.players.map((p) => Player.fromJSON(p)),
      turn: data.turn,
      round: data.round,
      pool: data.pool ?? 0,
      phase: data.phase,
      attack: data.attack ?? null,
      dice: data.dice ?? null,
      winner: data.winner ?? null,
      end: data.end ?? null,
      fx: data.fx ?? null,
      log: Array.isArray(data.log) ? data.log : [],
    });
  }
}
