import { WINNER } from '../config/rules.js';
import { findCountry } from '../data/countries.js';

export const STATUS = Object.freeze({ LIVE: 'live', WON: 'won', LOST: 'lost' });

export class GameSummary {
  #id;
  #ownerName;
  #country;
  #round;
  #created;
  #winner;

  constructor({ id, ownerName, country, round, created, winner }) {
    this.#id = id;
    this.#ownerName = ownerName;
    this.#country = country;
    this.#round = round;
    this.#created = created;
    this.#winner = winner;
  }

  get id() {
    return this.#id;
  }

  get ownerName() {
    return this.#ownerName;
  }

  get country() {
    return this.#country;
  }

  get flag() {
    return findCountry(this.#country)?.flag ?? '';
  }

  get round() {
    return this.#round;
  }

  get created() {
    return this.#created;
  }

  get status() {
    if (this.#winner === null) return STATUS.LIVE;
    return this.#winner === WINNER.HUMAN ? STATUS.WON : STATUS.LOST;
  }

  matches(query, status) {
    const text = query.trim().toLowerCase();
    const textMatch = !text || `${this.#ownerName} ${this.#country}`.toLowerCase().includes(text);
    return textMatch && (!status || status === 'all' || this.status === status);
  }

  static fromDocument(data) {
    return new GameSummary({
      id: data.id,
      ownerName: data.ownerName,
      country: data.players?.[0]?.name ?? 'Unknown',
      round: data.round ?? 1,
      created: data.created ?? 0,
      winner: data.winner ?? null,
    });
  }

  static compare(a, b) {
    return b.created - a.created;
  }
}
