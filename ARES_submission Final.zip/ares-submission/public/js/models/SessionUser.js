import { sanitiseCallsign } from '../utils/validation.js';

export class SessionUser {
  #uid;
  #email;
  #callsign;

  constructor({ uid, email, callsign }) {
    this.#uid = uid;
    this.#email = email;
    this.#callsign = callsign;
  }

  get uid() {
    return this.#uid;
  }

  get email() {
    return this.#email;
  }

  get callsign() {
    return this.#callsign;
  }

  static fromFirebase(user) {
    if (!user) return null;
    const fallback = sanitiseCallsign((user.email ?? '').split('@')[0]);
    return new SessionUser({ uid: user.uid, email: user.email ?? '', callsign: sanitiseCallsign(user.displayName, fallback) });
  }
}
