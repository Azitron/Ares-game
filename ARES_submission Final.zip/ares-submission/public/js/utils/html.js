const ESCAPES = Object.freeze({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' });

export const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ESCAPES[ch]);

class SafeHtml {
  #value;

  constructor(value) {
    this.#value = value;
  }

  toString() {
    return this.#value;
  }
}

const renderValue = (value) => {
  if (value === null || value === undefined || value === false) return '';
  if (value instanceof SafeHtml) return value.toString();
  if (Array.isArray(value)) return value.map(renderValue).join('');
  return escapeHtml(value);
};

export const raw = (value) => new SafeHtml(String(value));

export const html = (strings, ...values) =>
  new SafeHtml(strings.reduce((out, chunk, i) => out + chunk + (i < values.length ? renderValue(values[i]) : ''), ''));

export const mount = (element, template) => {
  element.innerHTML = String(html`${template}`);
};
