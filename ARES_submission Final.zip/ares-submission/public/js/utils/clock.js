export class SystemClock {
  now() {
    return Date.now();
  }
}

export class FixedClock {
  #time;

  constructor(start = 0) {
    this.#time = start;
  }

  now() {
    return this.#time;
  }

  advance(ms) {
    this.#time += ms;
  }
}

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
