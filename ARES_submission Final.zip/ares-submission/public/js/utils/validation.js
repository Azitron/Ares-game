import { BOARD_SIZE, MAX_LOG_ENTRIES, PHASES } from '../config/rules.js';
import { ValidationError } from './errors.js';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const CALLSIGN_PATTERN = /^[A-Za-z0-9_-]{3,20}$/;
const GAME_ID_PATTERN = /^[A-Za-z0-9]{20}$/;

export const validateEmail = (value) => {
  const email = String(value ?? '').trim();
  if (!email) throw new ValidationError('Type your email first.', 'email');
  if (email.length > 120 || !EMAIL_PATTERN.test(email)) throw new ValidationError('That email looks off. Check for typos.', 'email');
  return email;
};

export const validateLoginPassword = (value) => {
  const password = String(value ?? '');
  if (!password) throw new ValidationError('Type a password first.', 'password');
  return password;
};

export const validateNewPassword = (value) => {
  const password = String(value ?? '');
  if (password.length < 8 || password.length > 64) throw new ValidationError('Password must be 8 to 64 characters.', 'password');
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) throw new ValidationError('Password needs at least one letter and one number.', 'password');
  return password;
};

export const validateCallsign = (value) => {
  const callsign = String(value ?? '').trim();
  if (!CALLSIGN_PATTERN.test(callsign)) throw new ValidationError('Callsign must be 3 to 20 letters, numbers, - or _.', 'callsign');
  return callsign;
};

export const sanitiseCallsign = (raw, fallback = 'operator') => {
  const cleaned = String(raw ?? '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 20);
  return cleaned.length >= 3 ? cleaned : fallback;
};

export const validateGameId = (value) => {
  const id = String(value ?? '');
  if (!GAME_ID_PATTERN.test(id)) throw new ValidationError('That game link is not valid.', 'id');
  return id;
};

export const isValidGameId = (value) => GAME_ID_PATTERN.test(String(value ?? ''));

export const validateCount = (value, min, max) => {
  const count = Number(value);
  if (!Number.isInteger(count) || count < min || count > max) throw new ValidationError(`Enter a whole number from ${min} to ${max}.`, 'count');
  return count;
};

export const clampCount = (value, min, max) => {
  const count = Math.trunc(Number(value));
  if (!Number.isFinite(count)) return min;
  return Math.min(max, Math.max(min, count));
};

const need = (condition, message) => {
  if (!condition) throw new ValidationError(message, 'game');
};

const isInt = (value, min, max = Number.MAX_SAFE_INTEGER) => Number.isInteger(value) && value >= min && value <= max;

export const assertGameDocument = (doc) => {
  need(doc && typeof doc === 'object', 'Game data is missing.');
  need(isValidGameId(doc.id), 'Game id is invalid.');
  need(typeof doc.owner === 'string' && doc.owner.length > 0, 'Game owner is missing.');
  need(typeof doc.ownerName === 'string' && doc.ownerName.length >= 1 && doc.ownerName.length <= 40, 'Owner name is invalid.');
  need(Array.isArray(doc.players) && doc.players.length === BOARD_SIZE, 'A game needs exactly 10 players.');
  need(Array.isArray(doc.countries) && doc.countries.length === BOARD_SIZE, 'A game needs exactly 10 countries.');
  doc.players.forEach((p) => need(typeof p.name === 'string' && typeof p.alive === 'boolean' && isInt(p.played, 0), 'A player record is invalid.'));
  doc.countries.forEach((c) =>
    need(
      typeof c.name === 'string' && typeof c.flag === 'string' && isInt(c.base, 1, 9) && isInt(c.soldiers, 0, 100000) &&
        isInt(c.owner, 0, BOARD_SIZE - 1) && Number.isFinite(c.pop) && c.pop >= 0 && Number.isFinite(c.pt),
      `Country record for ${c.name} is invalid.`,
    ),
  );
  need(isInt(doc.turn, 0, BOARD_SIZE - 1), 'Turn is invalid.');
  need(isInt(doc.round, 1), 'Round is invalid.');
  need(isInt(doc.pool, 0), 'Reinforcement pool is invalid.');
  need(Object.values(PHASES).includes(doc.phase), 'Phase is invalid.');
  need(doc.winner === null || doc.winner === 0 || doc.winner === -1, 'Winner is invalid.');
  need(Array.isArray(doc.log) && doc.log.length <= MAX_LOG_ENTRIES, 'Log is invalid.');
  return doc;
};
