export class RuleError extends Error {
  constructor(message) {
    super(message);
    this.name = 'RuleError';
  }
}

export class ValidationError extends Error {
  constructor(message, field = null) {
    super(message);
    this.name = 'ValidationError';
    this.field = field;
  }
}

export class EngineHalted extends Error {
  constructor() {
    super('Engine halted');
    this.name = 'EngineHalted';
  }
}

const FRIENDLY = Object.freeze({
  'auth/invalid-email': 'That email looks off. Check for typos or spaces.',
  'auth/invalid-credential': 'No match for that login. New here? Use the Create account tab first.',
  'auth/wrong-password': 'Wrong password. Try again.',
  'auth/user-not-found': 'No account with that email. Use the Create account tab first.',
  'auth/email-already-in-use': 'That email already has an account. Use Sign in.',
  'auth/weak-password': 'Password is too weak. Use 8+ characters with letters and numbers.',
  'auth/missing-password': 'Type a password first.',
  'auth/too-many-requests': 'Too many attempts. Wait a minute and try again.',
  'auth/network-request-failed': 'Network problem. Check your connection.',
  'auth/operation-not-allowed': 'Enable Email/Password in Firebase Authentication > Sign-in method.',
  'auth/invalid-api-key': 'The Firebase apiKey is wrong. Copy the config from Project settings > Your apps.',
  'auth/api-key-not-valid': 'The Firebase apiKey is wrong. Copy the config from Project settings > Your apps.',
  'permission-denied': 'Firestore blocked this request. Publish firestore.rules from the project.',
  unavailable: 'The database is unreachable right now. Try again shortly.',
});

export const friendlyError = (error) => {
  const code = error?.code ?? '';
  return FRIENDLY[code] ?? error?.message ?? String(error);
};
