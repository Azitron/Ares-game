const MONTHS = Object.freeze(['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']);

export const formatMillions = (millions) => {
  if (millions >= 1000) return `${(millions / 1000).toFixed(2)}B`;
  if (millions >= 1) return `${+millions.toFixed(millions < 10 ? 1 : 0)}M`;
  return `${+(millions * 1000).toFixed(millions < 0.01 ? 1 : 0)}K`;
};

export const formatPeople = (millions) => Math.round(millions * 1e6).toLocaleString('en');

export const formatCompactPeople = (millions) => {
  const people = millions * 1e6;
  if (people >= 1e6) return `${+(people / 1e6).toFixed(1)}M`;
  if (people >= 1e3) return `${Math.round(people / 1e3)}K`;
  return String(Math.round(people));
};

export const formatGameDate = (ms) => {
  const date = new Date(ms);
  return `${date.getUTCDate()} ${MONTHS[date.getUTCMonth()]} ${date.getUTCFullYear()}`;
};

export const formatSigned = (value) => (value >= 0 ? `+${value}` : String(value));
