export class Rng {
  #source;

  constructor(source = Math.random) {
    this.#source = source;
  }

  int(max) {
    return 1 + Math.floor(this.#source() * max);
  }

  pick(items) {
    return items[this.int(items.length) - 1];
  }

  shuffle(items) {
    const copy = [...items];
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(this.#source() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  static seeded(seed) {
    let state = seed >>> 0;
    return new Rng(() => {
      state = (state + 0x6d2b79f5) >>> 0;
      let t = state;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    });
  }
}
