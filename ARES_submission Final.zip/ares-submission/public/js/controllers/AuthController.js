import { ValidationError, friendlyError } from '../utils/errors.js';
import { mount } from '../utils/html.js';
import { BaseController } from './BaseController.js';

export class AuthController extends BaseController {
  #root;
  #auth;
  #users;
  #view;
  #mode = 'signin';

  constructor({ root, auth, users, view }) {
    super();
    this.#root = root;
    this.#auth = auth;
    this.#users = users;
    this.#view = view;
  }

  show(mode = 'signin', error = '') {
    this.dispose();
    this.#mode = mode;
    mount(this.#root, this.#view.render({ mode, error }));
    this.listen(this.#root, 'click', (event) => {
      const tab = event.target.closest('[data-mode]');
      if (tab) this.show(tab.dataset.mode);
    });
    this.listen(this.#root, 'submit', (event) => {
      event.preventDefault();
      this.#submit(event.target);
    });
  }

  #showError(message) {
    const target = this.#root.querySelector('#auth-error');
    if (target) target.textContent = message;
  }

  async #submit(form) {
    const data = Object.fromEntries(new FormData(form));
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      if (this.#mode === 'register') {
        const user = await this.#auth.register(data);
        await this.#users.ensureProfile(user);
      } else {
        const user = await this.#auth.signIn(data);
        await this.#users.ensureProfile(user).catch(() => null);
      }
    } catch (error) {
      this.#showError(error instanceof ValidationError ? error.message : friendlyError(error));
      button.disabled = false;
    }
  }
}
