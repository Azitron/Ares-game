export class BaseController {
  #abort = new AbortController();

  listen(target, type, handler) {
    target.addEventListener(type, handler, { signal: this.#abort.signal });
  }

  dispose() {
    this.#abort.abort();
    this.#abort = new AbortController();
  }
}
