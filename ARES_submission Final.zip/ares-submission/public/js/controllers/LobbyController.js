import { RuleError, ValidationError, friendlyError } from '../utils/errors.js';
import { mount } from '../utils/html.js';
import { BaseController } from './BaseController.js';

const EMPTY_FILTER = Object.freeze({ q: '', status: 'all' });

export class LobbyController extends BaseController {
  #root;
  #repo;
  #factory;
  #router;
  #notifier;
  #view;
  #catalogue;
  #panels;
  #publicLimit;
  #confirm;
  #user = null;
  #runs = { mine: [], public: [] };
  #filters = { mine: { ...EMPTY_FILTER }, public: { ...EMPTY_FILTER } };

  constructor({ root, repo, factory, router, notifier, view, catalogue, panels, publicLimit, confirm }) {
    super();
    this.#root = root;
    this.#repo = repo;
    this.#factory = factory;
    this.#router = router;
    this.#notifier = notifier;
    this.#view = view;
    this.#catalogue = catalogue;
    this.#panels = panels;
    this.#publicLimit = publicLimit;
    this.#confirm = confirm;
  }

  async show(user) {
    this.dispose();
    this.#user = user;
    this.#runs = { mine: [], public: [] };
    this.#filters = { mine: { ...EMPTY_FILTER }, public: { ...EMPTY_FILTER } };
    mount(this.#root, this.#view.render({
      countries: this.#catalogue,
      myPanel: this.#panels.mine,
      publicPanel: this.#panels.public,
      stats: this.#stats(),
    }));
    this.listen(this.#root, 'submit', (event) => {
      event.preventDefault();
      this.#guard(() => this.#deploy(new FormData(event.target).get('country')));
    });
    this.listen(this.#root, 'input', (event) => this.#onFilter(event));
    this.listen(this.#root, 'change', (event) => this.#onFilter(event));
    this.listen(this.#root, 'click', (event) => {
      const remove = event.target.closest('[data-delete]');
      if (remove) this.#guard(() => this.#remove(remove.dataset.delete));
    });
    await Promise.all([this.#loadMine(), this.#loadPublic()]);
  }

  async #guard(action) {
    try {
      await action();
    } catch (error) {
      const known = error instanceof RuleError || error instanceof ValidationError;
      this.#notifier.show(known ? error.message : friendlyError(error), 'error', 6000);
    }
  }

  async #deploy(countryName) {
    const game = this.#factory.create({
      id: this.#repo.newId(),
      ownerUid: this.#user.uid,
      ownerName: this.#user.callsign,
      playerCountry: countryName,
    });
    await this.#repo.save(game);
    this.#router.navigate(`?g=${game.id}`);
  }

  async #remove(id) {
    if (!this.#confirm('Delete this run permanently?')) return;
    await this.#repo.remove(id);
    this.#runs.mine = this.#runs.mine.filter((run) => run.id !== id);
    this.#runs.public = this.#runs.public.filter((run) => run.id !== id);
    this.#renderPanels();
  }

  async #loadMine() {
    this.#runs.mine = await this.#repo.listByOwner(this.#user.uid).catch((error) => this.#fail(error));
    this.#renderPanels();
  }

  async #loadPublic() {
    this.#runs.public = await this.#repo.listPublic(this.#publicLimit).catch((error) => this.#fail(error));
    this.#renderPanels();
  }

  #fail(error) {
    this.#notifier.show(friendlyError(error), 'error', 6000);
    return [];
  }

  #onFilter(event) {
    const input = event.target.closest('[data-filter]');
    if (!input) return;
    const { filter: key, field } = input.dataset;
    if (this.#filters[key][field] === input.value) return;
    this.#filters[key][field] = input.value;
    this.#renderPanel(key);
  }

  #renderPanels() {
    this.#renderPanel('mine');
    this.#renderPanel('public');
    const stats = this.#root.querySelector('#stats');
    if (stats) mount(stats, this.#view.stats(this.#stats()));
  }

  #renderPanel(key) {
    const panel = this.#panels[key];
    const target = this.#root.querySelector(`#${panel.itemsId}`);
    if (!target) return;
    const { q, status } = this.#filters[key];
    const runs = this.#runs[key];
    mount(target, panel.items(runs, runs.filter((run) => run.matches(q, status))));
  }

  #stats() {
    const mine = this.#runs.mine;
    const count = (status) => mine.filter((run) => run.status === status).length;
    return { total: mine.length, live: count('live'), won: count('won'), lost: count('lost') };
  }
}
