import { COUNTRIES } from '../data/countries.js';
import { AiClient } from '../ai/AiClient.js';
import { GameFactory } from '../engine/GameFactory.js';
import { friendlyError } from '../utils/errors.js';
import { Rng } from '../utils/rng.js';
import { SystemClock, sleep } from '../utils/clock.js';
import { AuthService } from '../services/AuthService.js';
import { FirebaseConnection } from '../services/FirebaseConnection.js';
import { GameRepository } from '../services/GameRepository.js';
import { UserRepository } from '../services/UserRepository.js';
import { CountPrompt } from '../views/CountPrompt.js';
import { GameView } from '../views/game/GameView.js';
import { HowToPlayView } from '../views/HowToPlayView.js';
import { LobbyView } from '../views/LobbyView.js';
import { LoginView } from '../views/LoginView.js';
import { Modal } from '../views/Modal.js';
import { Notifier } from '../views/Notifier.js';
import { RunsPanel } from '../views/RunsPanel.js';
import { Shell } from '../views/Shell.js';
import { AuthController } from './AuthController.js';
import { GameController } from './GameController.js';
import { LobbyController } from './LobbyController.js';
import { Router } from './Router.js';

export class App {
  #win;
  #doc;
  #auth;
  #router;
  #shell;
  #notifier;
  #modal;
  #howTo = new HowToPlayView();
  #controllers;
  #user = null;
  #ready = false;
  #config;

  constructor({ win, doc, config, sdk }) {
    this.#win = win;
    this.#doc = doc;
    const clock = new SystemClock();
    const rng = new Rng();
    const connection = new FirebaseConnection({ sdk, config: config.firebase });
    this.#auth = new AuthService({ sdk, auth: connection.auth });
    const repo = new GameRepository({ sdk, db: connection.db });
    const users = new UserRepository({ sdk, db: connection.db, clock });
    const ai = new AiClient({ endpoint: config.llmEndpoint, getToken: () => this.#auth.token(), clock, ...config.ai });
    const root = doc.getElementById('view');
    this.#router = new Router(win);
    this.#shell = new Shell(doc.getElementById('userbar'));
    this.#notifier = new Notifier(doc.getElementById('toast'));
    this.#modal = new Modal(doc);
    const factory = new GameFactory({ catalogue: COUNTRIES, rng, clock });
    this.#controllers = {
      auth: new AuthController({ root, auth: this.#auth, users, view: new LoginView() }),
      lobby: new LobbyController({
        root,
        repo,
        factory,
        router: this.#router,
        notifier: this.#notifier,
        view: new LobbyView(),
        catalogue: COUNTRIES,
        panels: {
          mine: new RunsPanel({ id: 'mine', title: 'Your runs', emptyText: 'No runs yet. Deploy one.', canDelete: true }),
          public: new RunsPanel({ id: 'public', title: 'Live on the grid', emptyText: 'The grid is quiet.' }),
        },
        publicLimit: config.lists.publicLimit,
        confirm: (message) => win.confirm(message),
      }),
      game: new GameController({
        root,
        view: new GameView(root),
        repo,
        notifier: this.#notifier,
        clock,
        rng,
        sleep,
        ai,
        pacing: config.pacing,
        prompts: new CountPrompt(this.#modal),
        atlasUrl: config.atlasUrl,
        copyText: (text) => win.navigator.clipboard.writeText(text),
        shareUrl: () => win.location.href,
      }),
    };
    this.#config = config;
  }

  start() {
    this.#warnAboutSetup();
    this.#bindGlobalEvents();
    this.#router.onChange(() => this.#route());
    this.#auth.onChange((user) => {
      this.#user = user;
      this.#ready = true;
      this.#shell.renderUser(user);
      this.#route();
    });
  }

  #route() {
    if (!this.#ready) return;
    const { auth, lobby, game } = this.#controllers;
    [auth, lobby].forEach((controller) => controller.dispose());
    game.close();
    this.#notifier.clear();
    const route = this.#router.route;
    if (route.name === 'game') game.open(route.id, this.#user);
    else if (this.#user) lobby.show(this.#user);
    else auth.show();
  }

  #warnAboutSetup() {
    if (this.#win.location.protocol === 'file:') {
      this.#notifier.show('Firebase will not work from file://. Run a local server or deploy to Hosting, then open the http link.');
    } else if (String(this.#config.firebase.apiKey).startsWith('YOUR_')) {
      this.#notifier.show('Setup needed: paste your Firebase web config into js/config/appConfig.js.');
    }
  }

  #bindGlobalEvents() {
    this.#doc.addEventListener('click', (event) => {
      const link = event.target.closest('a[data-route]');
      if (link && !event.metaKey && !event.ctrlKey) {
        event.preventDefault();
        this.#router.navigate(link.getAttribute('href'));
        return;
      }
      const action = event.target.closest('[data-act]')?.dataset.act;
      if (action === 'logout') this.#auth.signOut();
      else if (action === 'dismiss') this.#notifier.clear();
      else if (action === 'help') this.#openHelp();
    });
    this.#win.addEventListener('unhandledrejection', (event) => this.#notifier.show(friendlyError(event.reason)));
    this.#win.addEventListener('error', (event) => this.#notifier.show(event.message));
  }

  #openHelp() {
    const element = this.#modal.open(this.#howTo.render(), { label: 'How to play', onDismiss: () => this.#modal.close() });
    element.querySelector('[data-act="close"]').addEventListener('click', () => this.#modal.close());
  }
}
