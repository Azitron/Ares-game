import { AiAssistedStrategy, RulesStrategy } from '../engine/NpcStrategy.js';
import { GameEngine } from '../engine/GameEngine.js';
import { PopulationModel } from '../engine/PopulationModel.js';
import { Commentator } from '../ai/Commentator.js';
import { HUMAN, PHASES } from '../config/rules.js';
import { RuleError, ValidationError, friendlyError } from '../utils/errors.js';
import { BaseController } from './BaseController.js';

const emptySelection = () => ({ from: null, to: null, mode: null });

export class GameController extends BaseController {
  #deps;
  #view;
  #game = null;
  #engine = null;
  #population = null;
  #selection = emptySelection();
  #isOwner = false;
  #active = false;
  #unsubscribe = null;
  #tickTimer = null;
  #lastTurn = null;
  #saving = false;
  #dirty = false;

  constructor(deps) {
    super();
    this.#deps = deps;
    this.#view = deps.view;
  }

  async open(id, user) {
    this.close();
    const { repo, notifier } = this.#deps;
    let game;
    try {
      game = await repo.load(id);
    } catch (error) {
      this.#view.showMissing(error instanceof ValidationError ? error.message : friendlyError(error));
      return;
    }
    if (!game) {
      this.#view.showMissing('No game lives at this link.');
      return;
    }
    this.#active = true;
    this.#game = game;
    this.#lastTurn = game.turn;
    this.#isOwner = Boolean(user) && game.ownerUid === user.uid;
    this.#population = new PopulationModel(game, this.#deps.clock);
    this.#view.mount();
    this.#view.map.loadAtlas(this.#deps.atlasUrl).then(() => {
      this.#render();
      this.#view.map.centreOn(this.#game);
    });
    this.#bindEvents();
    this.#tickTimer = setInterval(() => this.#view.tick(this.#game, this.#population), 200);
    if (this.#isOwner) this.#startEngine(game);
    else {
      this.#unsubscribe = repo.subscribe(
        id,
        (next) => this.#receive(next),
        (error) => notifier.show(friendlyError(error), 'error', 6000),
      );
    }
    this.#render();
  }

  close() {
    this.#active = false;
    this.dispose();
    clearInterval(this.#tickTimer);
    this.#unsubscribe?.();
    this.#unsubscribe = null;
    this.#engine?.halt();
    this.#engine = null;
    this.#selection = emptySelection();
  }

  #startEngine(game) {
    const { clock, rng, sleep, ai, pacing, prompts } = this.#deps;
    this.#engine = new GameEngine({
      game,
      rng,
      clock,
      commentator: new Commentator({ ai, rng }),
      strategy: new AiAssistedStrategy({ fallback: new RulesStrategy(), ai, isFast: () => Boolean(this.#engine?.fast) }),
      prompts,
      notify: () => this.#onEngineChange(),
      onError: (error) => this.#report(error),
      sleep,
      pacing,
    });
    this.#population = this.#engine.population;
    this.#engine.resume();
  }

  #receive(next) {
    if (!this.#active) return;
    if (!next) {
      this.#view.showMissing('This run was deleted by its owner.');
      return;
    }
    this.#game = next;
    this.#population = new PopulationModel(next, this.#deps.clock);
    this.#render();
  }

  #onEngineChange() {
    if (!this.#active) return;
    if (this.#game.turn !== this.#lastTurn) {
      this.#lastTurn = this.#game.turn;
      this.#selection = emptySelection();
    }
    this.#render();
    this.#persist();
  }

  #persist() {
    if (this.#saving) {
      this.#dirty = true;
      return;
    }
    this.#saving = true;
    this.#deps.repo
      .save(this.#game)
      .catch((error) => this.#report(error))
      .finally(() => {
        this.#saving = false;
        if (this.#dirty && this.#active) {
          this.#dirty = false;
          this.#persist();
        }
      });
  }

  #report(error) {
    const known = error instanceof RuleError || error instanceof ValidationError;
    this.#deps.notifier.show(known ? error.message : friendlyError(error), 'error', 6000);
  }

  #viewModel() {
    const engine = this.#engine;
    return {
      game: this.#game,
      population: this.#population,
      selection: this.#selection,
      isOwner: this.#isOwner,
      isMyTurn: Boolean(engine?.isHumanTurn),
      busy: Boolean(engine?.busy),
      fast: Boolean(engine?.fast),
      aiStatus: this.#deps.ai.status,
    };
  }

  #render() {
    if (this.#active && this.#game) this.#view.update(this.#viewModel());
  }

  #bindEvents() {
    const root = this.#deps.root;
    this.listen(root, 'click', (event) => this.#onClick(event));
    this.listen(root, 'keydown', (event) => {
      const node = event.target.closest?.('.nd');
      if (node && (event.key === 'Enter' || event.key === ' ')) {
        event.preventDefault();
        this.#guard(() => this.#selectTile(Number(node.dataset.i), event.shiftKey));
      }
    });
  }

  #onClick(event) {
    if (event.target.closest('#boom')) {
      this.#view.map.effects.clearBoom();
      return;
    }
    const tile = event.target.closest('.rw, .nd');
    if (tile) {
      this.#guard(() => this.#selectTile(Number(tile.dataset.i), event.shiftKey));
      return;
    }
    const button = event.target.closest('[data-a]');
    if (button && !button.disabled) this.#guard(() => this.#runAction(button.dataset.a));
  }

  async #guard(action) {
    try {
      await action();
    } catch (error) {
      this.#report(error);
    }
    this.#render();
  }

  async #selectTile(index, placeAll) {
    const engine = this.#engine;
    const game = this.#game;
    if (!engine || !engine.isHumanTurn || game.attack || engine.busy) return;
    const country = game.countries[index];
    if (!country) return;
    if (game.phase === PHASES.REINFORCE) {
      if (country.owner === HUMAN) engine.reinforce(index, placeAll ? game.pool : 1);
      return;
    }
    if (this.#selection.mode === 'transfer') {
      if (country.owner === HUMAN && this.#selection.from !== index) {
        const from = this.#selection.from;
        this.#selection.mode = null;
        await engine.transfer(from, index);
      }
      return;
    }
    if (country.owner === HUMAN) this.#selection.from = index;
    else this.#selection.to = index;
  }

  async #runAction(action) {
    const engine = this.#engine;
    const selection = this.#selection;
    if (action === 'share') {
      await this.#deps.copyText(this.#deps.shareUrl());
      this.#deps.notifier.show('Link copied to clipboard.', 'info', 2500);
    } else if (action === 'nuke') {
      this.#view.map.effects.reset();
      this.#game.replayFx(this.#deps.clock.now());
    } else if (action === 'ff') {
      engine.toggleFast();
    } else if (action === 'xf') {
      selection.mode = 'transfer';
    } else if (action === 'atk') {
      engine.startAttack(selection.from, selection.to);
    } else if (action === 'roll') {
      await engine.roll();
    } else if (action === 'back') {
      await engine.fallBack();
      this.#selection = emptySelection();
    }
  }
}
