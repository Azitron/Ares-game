export class Router {
  #window;
  #listeners = new Set();

  constructor(win) {
    this.#window = win;
    win.addEventListener('popstate', () => this.#emit());
  }

  get route() {
    const id = new URLSearchParams(this.#window.location.search).get('g');
    return id ? { name: 'game', id } : { name: 'lobby' };
  }

  navigate(target) {
    const url = target.startsWith('?') ? target : this.#window.location.pathname;
    this.#window.history.pushState({}, '', url);
    this.#emit();
  }

  onChange(listener) {
    this.#listeners.add(listener);
    return () => this.#listeners.delete(listener);
  }

  #emit() {
    this.#listeners.forEach((listener) => listener(this.route));
  }
}
