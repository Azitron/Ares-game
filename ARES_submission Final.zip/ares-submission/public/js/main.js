import { APP_CONFIG } from './config/appConfig.js';
import { App } from './controllers/App.js';
import * as sdk from './services/firebaseSdk.js';

new App({ win: window, doc: document, config: APP_CONFIG, sdk }).start();
