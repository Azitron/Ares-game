export const BOARD_SIZE = 10;
export const HUMAN = 0;
export const REQUIRED_COUNTRY = 'South Africa';
export const SOLDIER_TIERS = Object.freeze([5, 10, 25, 50, 75, 100, 125, 150]);
export const MAX_SOLDIER_BASE = 9;
export const REINFORCE_PER_COUNTRY = 2;
export const MIN_CONQUEST_GARRISON = 2;
export const MAX_LOG_ENTRIES = 80;
export const DAY_MS = 86400000;

export const POPULATION = Object.freeze({
  growthPerSecond: 2.5e-5,
  growthCapSeconds: 1800,
  clockCapMs: 3600000,
  draftLoss: 0.005,
  battleLoss: 0.01,
  conquestLoss: 0.03,
});

export const NPC = Object.freeze({
  minimumScore: 1,
  retreatRatio: 0.7,
  bigCountryBase: 7,
  bigCountryBonus: 0.5,
  weakDefenderLimit: 2,
  weakDefenderBonus: 1,
});

export const OWNER_COLOURS = Object.freeze([
  '#ffd23f', '#ff4d6d', '#b86bff', '#2ee07a', '#ff8a3d',
  '#ff6ec7', '#7a5cff', '#b7e84a', '#e8e8e8', '#8be9fd',
]);

export const PHASES = Object.freeze({ ACT: 'act', REINFORCE: 'reinforce' });
export const WINNER = Object.freeze({ HUMAN: 0, NPC: -1 });
