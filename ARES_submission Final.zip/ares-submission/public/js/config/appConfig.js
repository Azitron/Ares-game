export const APP_CONFIG = Object.freeze({
  firebase: Object.freeze({
    apiKey: 'AIzaSyBfX0DVBBDY_-tl_x20NK1uU9n_SuDOdjs',
    authDomain: 'ares-run-the-world.firebaseapp.com',
    projectId: 'ares-run-the-world',
    appId: '1:60493583813:web:59644d3bbb76cd933f67ac',
  }),
  llmEndpoint: 'PASTE_FUNCTION_URL_HERE',
  ai: Object.freeze({ timeoutMs: 9000, fastTimeoutMs: 3500, cooldownMs: 30000 }),
  pacing: Object.freeze({ normalMs: 1000, fastMs: 220 }),
  lists: Object.freeze({ publicLimit: 50 }),
  atlasUrl: 'https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-110m.json',
});
