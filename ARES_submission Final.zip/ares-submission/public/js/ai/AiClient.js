export const AI_STATUS = Object.freeze({ TEMPLATES: 'templates', READY: 'ready', LIVE: 'live', OFFLINE: 'offline' });

export class AiClient {
  #endpoint;
  #getToken;
  #fetch;
  #clock;
  #timeoutMs;
  #fastTimeoutMs;
  #cooldownMs;
  #healthy = null;
  #blockedUntil = 0;

  constructor({ endpoint, getToken, fetchFn = (...args) => fetch(...args), clock, timeoutMs = 9000, fastTimeoutMs = 3500, cooldownMs = 30000 }) {
    this.#endpoint = endpoint;
    this.#getToken = getToken;
    this.#fetch = fetchFn;
    this.#clock = clock;
    this.#timeoutMs = timeoutMs;
    this.#fastTimeoutMs = fastTimeoutMs;
    this.#cooldownMs = cooldownMs;
  }

  get enabled() {
    return /^https:\/\//.test(this.#endpoint ?? '');
  }

  get status() {
    if (!this.enabled) return AI_STATUS.TEMPLATES;
    if (this.#healthy === null) return AI_STATUS.READY;
    return this.#healthy ? AI_STATUS.LIVE : AI_STATUS.OFFLINE;
  }

  async request(body, { fast = false } = {}) {
    if (!this.enabled || this.#clock.now() < this.#blockedUntil) return null;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), fast ? this.#fastTimeoutMs : this.#timeoutMs);
    try {
      const token = await this.#getToken();
      if (!token) return null;
      const response = await this.#fetch(this.#endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const json = await response.json();
      this.#healthy = true;
      return json;
    } catch (error) {
      this.#healthy = false;
      this.#blockedUntil = this.#clock.now() + this.#cooldownMs;
      return null;
    } finally {
      clearTimeout(timer);
    }
  }
}
