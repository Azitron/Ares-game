export const battleLine = (attacker, defender, attackerLosses, defenderLosses, rng) => {
  if (!attackerLosses && !defenderLosses) {
    return rng.pick([
      `Sparks and stalemate. ${attacker} and ${defender} trade glares, nobody bleeds.`,
      'Dead heat. The grid holds its breath.',
    ]);
  }
  if (defenderLosses && !attackerLosses) {
    return rng.pick([
      `${attacker} rips through ${defender}'s firewall: ${defenderLosses} down, zero losses.`,
      `Clean hit. ${defender} loses ${defenderLosses} and the neon flickers.`,
    ]);
  }
  if (attackerLosses && !defenderLosses) {
    return rng.pick([
      `${defender}'s defences laugh it off. ${attacker} burns ${attackerLosses}.`,
      `Counter-hack! ${attacker} loses ${attackerLosses} to cold return fire.`,
    ]);
  }
  return `Chrome on chrome: ${attacker} -${attackerLosses}, ${defender} -${defenderLosses}. Bloody trade.`;
};

export const conquestLine = (attacker, defender, garrison) =>
  `${defender} goes dark. ${attacker} plants the flag with ${garrison} troops.`;
