import { battleLine, conquestLine } from './templates.js';

export class Commentator {
  #ai;
  #rng;

  constructor({ ai, rng }) {
    this.#ai = ai;
    this.#rng = rng;
  }

  get status() {
    return this.#ai.status;
  }

  async battle({ attacker, defender, result, fast }) {
    const fallback = battleLine(attacker.name, defender.name, result.attackerLosses, result.defenderLosses, this.#rng);
    if (fast) return fallback;
    const event = `${attacker.name} [${result.attackerDice}] vs ${defender.name} [${result.defenderDice}] -> -${result.attackerLosses}/-${result.defenderLosses}`;
    return this.#narrate(event, fallback, false);
  }

  async conquest({ attacker, defender, garrison, fast }) {
    const fallback = conquestLine(attacker.name, defender.name, garrison);
    return this.#narrate(`${attacker.name} conquers ${defender.name}`, fallback, fast);
  }

  async #narrate(event, fallback, fast) {
    const reply = await this.#ai.request({ type: 'commentary', event }, { fast });
    return typeof reply?.text === 'string' && reply.text ? reply.text : fallback;
  }
}
