import { HUMAN, PHASES, POPULATION, WINNER } from '../config/rules.js';
import { EngineHalted, RuleError } from '../utils/errors.js';
import { clampCount } from '../utils/validation.js';
import { BattleEngine } from './BattleEngine.js';
import { PopulationModel } from './PopulationModel.js';
import { conquestGarrison } from './Rules.js';

export class GameEngine {
  #game;
  #rng;
  #clock;
  #commentator;
  #strategy;
  #prompts;
  #notify;
  #onError;
  #sleep;
  #pacing;
  #battle;
  #population;
  #fast = false;
  #busy = false;
  #running = false;
  #halted = false;
  #loop = null;

  constructor({ game, rng, clock, commentator, strategy, prompts, notify, onError, sleep, pacing }) {
    this.#game = game;
    this.#rng = rng;
    this.#clock = clock;
    this.#commentator = commentator;
    this.#strategy = strategy;
    this.#prompts = prompts;
    this.#notify = notify;
    this.#onError = onError;
    this.#sleep = sleep;
    this.#pacing = pacing;
    this.#battle = new BattleEngine(rng);
    this.#population = new PopulationModel(game, clock);
  }

  get game() {
    return this.#game;
  }

  get population() {
    return this.#population;
  }

  get fast() {
    return this.#fast;
  }

  get busy() {
    return this.#busy;
  }

  get isHumanTurn() {
    return !this.#game.isOver && this.#game.turn === HUMAN && !this.#running;
  }

  toggleFast() {
    this.#fast = !this.#fast;
    return this.#fast;
  }

  #requireHumanTurn() {
    if (!this.isHumanTurn) throw new RuleError('It is not your turn.');
    if (this.#busy) throw new RuleError('Wait for the current action to finish.');
  }

  #requireActPhase() {
    if (this.#game.phase !== PHASES.ACT) throw new RuleError('Place your reinforcements first.');
  }

  async #exclusive(action) {
    this.#requireHumanTurn();
    this.#busy = true;
    try {
      return await action();
    } finally {
      this.#busy = false;
      this.#notify();
    }
  }

  #post(owner, text, why = '') {
    this.#game.appendLog({ i: owner, t: text, w: why });
    this.#notify();
  }

  halt() {
    this.#halted = true;
  }

  #delay() {
    if (this.#halted) throw new EngineHalted();
    return this.#sleep(this.#fast ? this.#pacing.fastMs : this.#pacing.normalMs);
  }

  startAttack(fromIndex, toIndex) {
    this.#requireHumanTurn();
    this.#requireActPhase();
    if (this.#game.attack) throw new RuleError('An attack is already in progress.');
    const from = this.#game.countries[fromIndex];
    const to = this.#game.countries[toIndex];
    if (!from || !to) throw new RuleError('Pick a striker and a target first.');
    if (from.owner !== HUMAN) throw new RuleError('Pick one of your own countries to strike from.');
    if (to.owner === HUMAN) throw new RuleError('Pick an enemy country as the target.');
    if (from.soldiers < 2) throw new RuleError(`${from.name} needs at least 2 soldiers to attack.`);
    this.#game.beginAttack(fromIndex, toIndex);
    this.#post(HUMAN, `${from.name} locks onto ${to.name}.`);
  }

  roll() {
    return this.#exclusive(async () => {
      const { attack, countries } = this.#game;
      if (!attack) throw new RuleError('Start an attack first.');
      const from = countries[attack.f];
      const to = countries[attack.t];
      await this.#fight(from, to);
      if (to.soldiers <= 0) {
        await this.#conquer(from, to);
        this.#finishHumanTurn();
      } else if (from.soldiers < 2) {
        this.#post(HUMAN, `${from.name} is down to one soldier. Strike over.`);
        this.#finishHumanTurn();
      }
    });
  }

  fallBack() {
    return this.#exclusive(async () => {
      this.#requireActPhase();
      const text = this.#game.attack ? 'You pull the plug and retreat.' : 'You hold position and let the grid breathe.';
      this.#post(HUMAN, text);
      this.#finishHumanTurn();
    });
  }

  reinforce(index, count) {
    this.#requireHumanTurn();
    const game = this.#game;
    if (game.phase !== PHASES.REINFORCE) throw new RuleError('No reinforcements to place.');
    const country = game.countries[index];
    if (!country || country.owner !== HUMAN) throw new RuleError('Place reinforcements on your own countries.');
    if (!Number.isInteger(count) || count < 1 || count > game.pool) throw new RuleError('Invalid reinforcement amount.');
    country.addSoldiers(count);
    this.#population.apply(country, 1 - POPULATION.draftLoss * count);
    game.setPool(game.pool - count);
    if (game.pool === 0) game.setPhase(PHASES.ACT);
    this.#notify();
  }

  transfer(fromIndex, toIndex) {
    return this.#exclusive(async () => {
      this.#requireActPhase();
      const game = this.#game;
      if (game.attack) throw new RuleError('Finish the attack before moving troops.');
      const from = game.countries[fromIndex];
      const to = game.countries[toIndex];
      if (!from || !to || from === to || from.owner !== HUMAN || to.owner !== HUMAN) throw new RuleError('Transfers go between two of your own countries.');
      const movable = from.soldiers - 1;
      if (movable < 1) throw new RuleError(`${from.name} must keep at least one soldier.`);
      const requested = await this.#prompts.askCount(`Rewire how many from ${from.name} to ${to.name}?`, movable);
      const count = clampCount(requested, 0, movable);
      if (!count) return;
      from.removeSoldiers(count);
      to.addSoldiers(count);
      this.#post(HUMAN, `${count} soldiers jacked from ${from.name} into ${to.name}.`);
    });
  }

  resume() {
    if (this.#loop) return this.#loop;
    this.#running = true;
    this.#loop = this.#playNpcTurns().finally(() => {
      this.#running = false;
      this.#loop = null;
      this.#notify();
    });
    return this.#loop;
  }

  async #playNpcTurns() {
    try {
      while (!this.#halted && !this.#game.isOver && this.#game.turn !== HUMAN) await this.#npcTurn();
    } catch (error) {
      if (!(error instanceof EngineHalted)) this.#onError(error);
    }
  }

  #finishHumanTurn() {
    if (!this.#game.isOver) this.#game.advanceTurn();
    this.#notify();
    queueMicrotask(() => this.resume());
  }

  async #fight(attacker, defender) {
    const game = this.#game;
    const result = this.#battle.resolve(attacker.soldiers, defender.soldiers);
    attacker.removeSoldiers(result.attackerLosses);
    defender.removeSoldiers(result.defenderLosses);
    const attackerPopulation = this.#population.current(attacker);
    const defenderPopulation = this.#population.current(defender);
    this.#population.apply(attacker, 1 - POPULATION.battleLoss * result.attackerLosses);
    this.#population.apply(defender, 1 - POPULATION.battleLoss * result.defenderLosses);
    const finalBlow = defender.soldiers <= 0 && this.#isDecisive(attacker, defender);
    game.recordRoll(
      { ad: result.attackerDice, dd: result.defenderDice, ai: attacker.owner, di: defender.owner },
      {
        f: game.indexOf(attacker),
        t: game.indexOf(defender),
        k: this.#clock.now(),
        n: finalBlow,
        v: attacker.owner === HUMAN,
        al: result.attackerLosses,
        dl: result.defenderLosses,
        pa: attackerPopulation * POPULATION.battleLoss * result.attackerLosses,
        pb: defenderPopulation * POPULATION.battleLoss * result.defenderLosses,
      },
    );
    const evidence = `${attacker.name} [${result.attackerDice}] vs ${defender.name} [${result.defenderDice}] -> -${result.attackerLosses}/-${result.defenderLosses}`;
    const text = await this.#commentator.battle({ attacker, defender, result, fast: this.#fast });
    this.#post(attacker.owner, text, evidence);
  }

  #isDecisive(attacker, defender) {
    const game = this.#game;
    if (attacker.owner === HUMAN) return game.countries.filter((c) => c.owner !== HUMAN).length === 1;
    return defender.owner === HUMAN && game.countriesOf(HUMAN).length === 1;
  }

  async #conquer(attacker, defender) {
    const game = this.#game;
    const previousOwner = defender.owner;
    const garrison = conquestGarrison(defender.base);
    defender.capture(attacker.owner, garrison);
    this.#population.apply(defender, 1 - POPULATION.conquestLoss);
    if (!game.countriesOf(previousOwner).length) game.players[previousOwner].eliminate();
    const text = await this.#commentator.conquest({ attacker, defender, garrison, fast: false });
    this.#post(attacker.owner, text, `Conquest bonus: max(2, ⌊${defender.base}/2⌋) = ${garrison}`);
    const spare = attacker.soldiers - 1;
    if (spare > 0) {
      const wanted = attacker.owner === HUMAN
        ? await this.#prompts.askCount(`Rewire troops into ${defender.name}? (${spare} spare)`, spare)
        : Math.floor(spare / 2);
      const moved = clampCount(wanted, 0, spare);
      attacker.removeSoldiers(moved);
      defender.addSoldiers(moved);
    }
    this.#settleWinner();
  }

  #settleWinner() {
    const game = this.#game;
    if (!game.players[HUMAN].alive) game.declareWinner(WINNER.NPC, this.#clock.now());
    else if (game.alivePlayers().length === 1) game.declareWinner(WINNER.HUMAN, this.#clock.now());
  }

  async #npcTurn() {
    const game = this.#game;
    const owner = game.turn;
    const name = game.players[owner].name;
    if (game.pool > 0) {
      const target = this.#strategy.chooseReinforcement(game, owner);
      const amount = game.pool;
      target.addSoldiers(amount);
      this.#population.apply(target, 1 - POPULATION.draftLoss * amount);
      this.#post(owner, `${name} drops +${amount} reinforcements on ${target.name}.`, 'Stack the biggest garrison: more dice per roll beats spreading thin.');
      game.setPool(0);
      await this.#delay();
    }
    game.setPhase(PHASES.ACT);
    const choice = await this.#strategy.chooseAttack(game, owner);
    if (!choice) {
      this.#post(owner, `${name} holds position.`, 'No target gives a dice edge. Waiting for reinforcements beats feeding soldiers to the grid.');
      await this.#delay();
    } else {
      const { from, to } = choice;
      this.#post(owner, `${from.name} (${from.soldiers}) targets ${to.name} (${to.soldiers}).`, choice.why);
      await this.#delay();
      await this.#assault(owner, from, to);
    }
    if (!game.isOver) game.advanceTurn();
    this.#notify();
  }

  async #assault(owner, from, to) {
    for (;;) {
      await this.#fight(from, to);
      await this.#delay();
      if (to.soldiers <= 0) {
        await this.#conquer(from, to);
        return;
      }
      if (from.soldiers < 2) {
        this.#post(owner, `${from.name} is spent.`, 'Down to one soldier: the attack ends.');
        return;
      }
      if (this.#strategy.shouldRetreat(from, to)) {
        this.#post(owner, `${from.name} pulls back.`, 'Odds flipped; stopping saves soldiers.');
        return;
      }
    }
  }
}
