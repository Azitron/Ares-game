import { MAX_SOLDIER_BASE, MIN_CONQUEST_GARRISON, REINFORCE_PER_COUNTRY, SOLDIER_TIERS } from '../config/rules.js';

export const soldiersForPopulation = (millions) => {
  const tier = SOLDIER_TIERS.findIndex((limit) => millions <= limit);
  return tier < 0 ? MAX_SOLDIER_BASE : tier + 1;
};

export const conquestGarrison = (base) => Math.max(MIN_CONQUEST_GARRISON, Math.floor(base / 2));

export const reinforcementsFor = (countryCount) => REINFORCE_PER_COUNTRY * countryCount;

export const diceCount = (attackerSoldiers, defenderSoldiers) => Math.max(0, Math.min(attackerSoldiers - 1, defenderSoldiers));

export const attackEdge = (attackerSoldiers, defenderSoldiers) => attackerSoldiers - 1 - defenderSoldiers;
