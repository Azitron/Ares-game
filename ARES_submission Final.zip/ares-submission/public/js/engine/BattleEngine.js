import { diceCount } from './Rules.js';

export class BattleEngine {
  #rng;

  constructor(rng) {
    this.#rng = rng;
  }

  resolve(attackerSoldiers, defenderSoldiers) {
    const count = diceCount(attackerSoldiers, defenderSoldiers);
    const roll = () => Array.from({ length: count }, () => this.#rng.int(6));
    const attackerDice = roll();
    const defenderDice = roll();
    let attackerLosses = 0;
    let defenderLosses = 0;
    attackerDice.forEach((die, i) => {
      if (die > defenderDice[i]) defenderLosses += 1;
      else if (die < defenderDice[i]) attackerLosses += 1;
    });
    return Object.freeze({ attackerDice, defenderDice, attackerLosses, defenderLosses });
  }
}
