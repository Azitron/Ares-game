import { BOARD_SIZE, PHASES, REQUIRED_COUNTRY } from '../config/rules.js';
import { Country } from '../models/Country.js';
import { Game } from '../models/Game.js';
import { Player } from '../models/Player.js';
import { RuleError } from '../utils/errors.js';
import { soldiersForPopulation } from './Rules.js';

export class GameFactory {
  #catalogue;
  #rng;
  #clock;

  constructor({ catalogue, rng, clock }) {
    this.#catalogue = catalogue;
    this.#rng = rng;
    this.#clock = clock;
  }

  #pickRivals(playerName) {
    const rivals = this.#rng.shuffle(this.#catalogue.filter((c) => c.name !== playerName)).slice(0, BOARD_SIZE - 1);
    const required = this.#catalogue.find((c) => c.name === REQUIRED_COUNTRY);
    if (required && playerName !== REQUIRED_COUNTRY && !rivals.includes(required)) {
      rivals[this.#rng.int(BOARD_SIZE - 1) - 1] = required;
    }
    return rivals;
  }

  create({ id, ownerUid, ownerName, playerCountry }) {
    const player = this.#catalogue.find((c) => c.name === playerCountry);
    if (!player) throw new RuleError(`Unknown country: ${playerCountry}`);
    const created = this.#clock.now();
    const roster = [player, ...this.#pickRivals(player.name)];
    const countries = roster.map((entry, owner) => {
      const base = soldiersForPopulation(entry.population);
      return new Country({ name: entry.name, flag: entry.flag, base, soldiers: base, owner, population: entry.population, stamp: created });
    });
    const players = roster.map((entry) => new Player({ name: entry.name }));
    return new Game({
      id,
      ownerUid,
      ownerName,
      created,
      countries,
      players,
      turn: this.#rng.int(BOARD_SIZE) - 1,
      phase: PHASES.ACT,
    });
  }
}
