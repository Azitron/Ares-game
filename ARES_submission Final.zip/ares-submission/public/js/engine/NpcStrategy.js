import { NPC } from '../config/rules.js';

export class RulesStrategy {
  chooseReinforcement(game, owner) {
    return [...game.countriesOf(owner)].sort((a, b) => b.soldiers - a.soldiers)[0];
  }

  async chooseAttack(game, owner) {
    let best = null;
    for (const from of game.countriesOf(owner)) {
      if (from.soldiers < 2) continue;
      for (const to of game.countries) {
        if (to.owner === owner) continue;
        const score = from.soldiers - 1 - to.soldiers +
          (to.base >= NPC.bigCountryBase ? NPC.bigCountryBonus : 0) +
          (to.soldiers <= NPC.weakDefenderLimit ? NPC.weakDefenderBonus : 0);
        if (!best || score > best.score) {
          best = {
            from,
            to,
            score,
            why: `Dice edge: ${from.soldiers - 1} attackers vs ${to.soldiers} defenders, and ${to.name} is worth ${to.base} base troops.`,
          };
        }
      }
    }
    return best && best.score >= NPC.minimumScore ? best : null;
  }

  shouldRetreat(from, to) {
    return from.soldiers - 1 < to.soldiers * NPC.retreatRatio;
  }
}

export class AiAssistedStrategy {
  #fallback;
  #ai;
  #isFast;

  constructor({ fallback, ai, isFast = () => false }) {
    this.#fallback = fallback;
    this.#ai = ai;
    this.#isFast = isFast;
  }

  chooseReinforcement(game, owner) {
    return this.#fallback.chooseReinforcement(game, owner);
  }

  shouldRetreat(from, to) {
    return this.#fallback.shouldRetreat(from, to);
  }

  async chooseAttack(game, owner) {
    const ruled = await this.#fallback.chooseAttack(game, owner);
    const reply = await this.#ai.request({
      type: 'decide',
      me: owner,
      board: game.countries.map((c) => ({ n: c.name, o: c.owner, s: c.soldiers })),
    }, { fast: this.#isFast() });
    if (!reply?.from) return ruled;
    const from = game.countries.find((c) => c.name === reply.from && c.owner === owner);
    const to = game.countries.find((c) => c.name === reply.to && c.owner !== owner);
    if (!from || !to || from.soldiers < 2) return ruled;
    return { from, to, score: Infinity, why: `AI: ${String(reply.why ?? '').slice(0, 140)}` };
  }
}
