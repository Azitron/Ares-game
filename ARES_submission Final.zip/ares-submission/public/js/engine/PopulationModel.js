import { DAY_MS, POPULATION } from '../config/rules.js';

export class PopulationModel {
  #game;
  #clock;

  constructor(game, clock) {
    this.#game = game;
    this.#clock = clock;
  }

  #reference() {
    return this.#game.end ?? this.#clock.now();
  }

  current(country) {
    const seconds = Math.min(POPULATION.growthCapSeconds, Math.max(0, (this.#reference() - country.stamp) / 1000));
    return country.population * (1 + POPULATION.growthPerSecond * seconds);
  }

  apply(country, factor) {
    country.setPopulation(+(this.current(country) * factor).toFixed(6), this.#clock.now());
  }

  total(countries) {
    return countries.reduce((sum, country) => sum + this.current(country), 0);
  }

  gameTime() {
    const elapsed = Math.min(this.#reference() - this.#game.created, POPULATION.clockCapMs);
    return this.#game.created + elapsed * (DAY_MS / 1000);
  }
}
