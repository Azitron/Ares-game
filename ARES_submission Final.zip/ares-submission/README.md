# ARES // World Run

A single-player, browser-based geopolitics strategy game (Risk-style) built for the UCT INF4001 Honours 2027 entrance exam. You command one of 10 countries on a live world map, fight dice battles against 9 NPC rivals, and finish the game with a nuclear strike and a VICTORY screen. South Africa is always on the board.

## 1. Submission details (fill in before you submit)

| Item | Value |
|---|---|
| Deployed site | `https://ares-run-the-world.web.app` (replace with the URL printed by `firebase deploy --only hosting`) |
| Marker login (app) | email: `PASTE_TEST_EMAIL` / password: `PASTE_TEST_PASSWORD` |
| Firebase project | `ares-run-the-world` |
| Database access for markers | Firebase console > Project settings > Users and permissions: add `ammarcanani@gmail.com`, `mc.tanner@uct.ac.za`, `ridewaan.hanslo@uct.ac.za` as Viewer |

## 2. Stack

| Layer | Technology |
|---|---|
| Front end | HTML, CSS, vanilla JavaScript (ES modules, no build step), d3 + topojson for the world map |
| Authentication | Firebase Authentication (email and password) |
| Database | Cloud Firestore (NoSQL, online), secured by `firestore.rules` |
| AI | OpenAI Chat Completions, called only from a Firebase Cloud Function (the API key never reaches the browser) |
| Hosting | Firebase Hosting |
| Tests | Node built-in test runner (unit) and Playwright (browser end-to-end) |

## 3. Architecture (MVC with a separate database layer)

```
public/
  index.html               page shell
  css/                     base, layout, components, map
  js/
    main.js                entry point
    config/                appConfig.js (Firebase config, AI endpoint), rules.js (game constants)
    data/                  countries.js (41 countries: population, flag, map position)
    models/                Country, Player, Game, GameSummary, SessionUser   (MODEL)
    engine/                GameEngine, BattleEngine, PopulationModel, GameFactory,
                           NpcStrategy, Rules                                 (GAME LOGIC)
    ai/                    AiClient, Commentator, templates                   (AI LAYER)
    services/              FirebaseConnection, AuthService, GameRepository,
                           UserRepository, firebaseSdk                        (DATABASE LAYER)
    views/                 Lobby, Login, Modal, Notifier, game/*, map/*       (VIEW)
    controllers/           App, Router, Auth, Lobby, Game controllers         (CONTROLLER)
    utils/                 html (auto-escaping templates), validation, rng, clock, format, errors
functions/                 Cloud Function: handler, prompts, RateLimiter, OpenAI client
firestore.rules            database security rules
firebase.json, .firebaserc deployment configuration
tests/                     unit, function and browser tests
docs/screenshots/          screenshots from the browser test run
```

Design choices a marker can look for:
- **Database layer is separate.** Nothing outside `js/services/` imports the Firebase SDK. `FirebaseConnection` holds the configuration and connection, `GameRepository` and `UserRepository` are the only classes that read or write data. The SDK is injected, so the repositories are unit-tested with a fake database.
- **Object-oriented.** `Country`, `Player` and `Game` use private fields (`#`), getters, and guarded mutators (for example `Country.removeSoldiers`, `Game.advanceTurn`), so invalid states cannot be created from outside. Strategy pattern for NPCs (`RulesStrategy`, `AiAssistedStrategy`), dependency injection throughout (clock, random generator, AI client, prompts), repository pattern for storage.
- **Pure, testable engine.** `BattleEngine` and `GameEngine` take an injectable random generator, so the whole game can be replayed deterministically in tests.
- **No comments in the code.** Names and small functions carry the meaning.

## 4. Data model (Firestore)

`games/{gameId}` (public read, owner-only write)

| Field | Type | Meaning |
|---|---|---|
| `id`, `owner`, `ownerName` | string | game id, owner's Firebase uid, owner's callsign |
| `created`, `end` | number / null | epoch ms when created / when the game ended |
| `players` | list of 10 | `{ name, alive, played }` |
| `countries` | list of 10 | `{ name, flag, base, soldiers, owner, pop, pt }` (`pop` and `pt` are the population value and the time it was stamped) |
| `turn`, `round`, `pool`, `phase` | number / string | whose turn, round, reinforcements left, `act` or `reinforce` |
| `attack`, `dice`, `fx` | map / null | attack in progress, last dice, last battle effect (drives missile, nuke and live numbers) |
| `winner` | null, 0 or -1 | null while live, 0 you won, -1 you lost |
| `log` | list (max 80) | `{ i, t, w }`: owner index, text, justification |

`users/{uid}` (signed-in read, self-only write): `{ callsign, created }`

## 5. Security

- Firebase Auth email/password. Passwords are 8 to 64 characters with a letter and a number; callsigns are 3 to 20 letters, numbers, `-` or `_`.
- Authorization (`firestore.rules`): anyone can read a game (public viewing); only a signed-in user can create a game they own; only the owner can update or delete it; the owner field can never be changed; documents must have 10 players, 10 countries, a valid phase and winner, and a log of at most 80 entries. Users can only write their own profile.
- Client-side validation (`utils/validation.js`) runs before every write; `GameRepository` refuses to save a malformed game document.
- Output escaping: every dynamic value goes through an auto-escaping `html` template tag, so a name or AI sentence cannot inject markup. Game ids are validated (20 alphanumerics) before use.
- Cloud Function: verifies the Firebase ID token, allows only configured origins, rate-limits each player (120 requests a minute), validates every request, and never returns upstream error details. The OpenAI key lives in Google Secret Manager.

## 6. How to play

Open the site, create an account (or sign in), pick a country and press **Deploy to the grid**. The **How to play** button in the header explains everything. In short:

1. Tap one of your countries, tap an enemy, press **STRIKE**, then **ROLL**. The attacker rolls (soldiers - 1) dice, the defender rolls up to its soldier count, the higher die of each pair kills one soldier, ties kill nobody.
2. When a defender reaches 0 soldiers you capture it and it receives max(2, half its base soldiers). You may then move spare troops in.
3. From round 2 you receive +2 soldiers per country you hold; tap your countries to place them (Shift places all).
4. **TRANSFER** moves soldiers between your countries when no attack is running. **FALL BACK** or **HOLD** ends your turn. **FAST** speeds up NPC turns.
5. Conquer all 10 countries to trigger the nuke finale. Population is live: it grows in real time and shrinks with drafting, losses and conquest.
6. Anyone with a run's link can watch it live as a spectator.

Starting soldiers come from population: up to 5M = 1, 10M = 2, 25M = 3, 50M = 4, 75M = 5, 100M = 6, 125M = 7, 150M = 8, above 150M = 9.

## 7. Run it

### Locally
```
npm start
```
This serves `public/` at http://localhost:8080 using the real Firebase project configured in `public/js/config/appConfig.js`. (Any static server works; opening `index.html` directly from the file system does not work with ES modules and Firebase.)

### Use your own Firebase project
1. Firebase console: create a project, add a Web app, and copy its config into `public/js/config/appConfig.js`.
2. Build > Authentication > Sign-in method: enable **Email/Password**.
3. Build > Firestore Database > create a database.
4. Install the CLI: `npm i -g firebase-tools`, then `firebase login` and `firebase use <your-project-id>`.
5. Publish the rules: `firebase deploy --only firestore:rules`.
6. Deploy the site: `firebase deploy --only hosting`.
7. Create a test account in the deployed site and put its details in section 1.

### Enable the AI (optional)
Without it the game works with built-in commentary and rules-based NPCs; the header pill shows `TEMPLATES`.
1. Upgrade the Firebase project to the Blaze plan (Cloud Functions and Secret Manager need billing). Set a spending limit in your OpenAI account.
2. Create an OpenAI API key, then store it: `firebase functions:secrets:set OPENAI_API_KEY`.
3. `cd functions && npm install && cd ..`, copy `functions/.env.example` to `functions/.env`, set `OPENAI_MODEL` and your project id in `ALLOWED_ORIGINS`.
4. `firebase deploy --only functions`. Copy the printed `aresLLM` URL into `llmEndpoint` in `public/js/config/appConfig.js`, then redeploy hosting.
5. Play a round: the header pill should read `AI LIVE`. If the AI is slow or down, the game falls back to templates for 30 seconds and keeps working.

What the AI does: writes a one-sentence commentary for each battle and conquest, and chooses each NPC's attack with a visible justification. The game checks every AI choice is legal and uses its rules-based choice otherwise.

## 8. Tests

```
npm install
npm test            # 69 unit tests (rules, battles, population, engine, NPC, models, validation, repositories, AI client, Cloud Function)
npm run test:e2e    # drives real Chromium: register, sign in, deploy, play, missile, nuke finale, spectator, search, filter, delete
```
The end-to-end test replaces Firebase with an in-browser fake so it runs offline. It checks the UI flows, not Firebase itself.

## 9. Marksheet map

| Criterion | Where |
|---|---|
| Database layer (separate, configuration, appropriate, online) | `js/services/`, `js/config/appConfig.js`, Cloud Firestore |
| Connection to database | `FirebaseConnection.js` |
| Design of the database | section 4, `firestore.rules` |
| Coding structure / framework | MVC folders in section 3 |
| Object-oriented concepts | `models/`, `engine/`, `services/` (classes, private fields, strategy, DI) |
| Validation, controls, security | `utils/validation.js`, `firestore.rules`, `utils/html.js`, section 5 |
| Functionality (lists, search, filter, view) | lobby run lists with search, status filter, stats, delete; spectator view; live ranking |
| User interface, navigation | idle-war themed UI, world map, header navigation, how-to-play dialog, keyboard-focusable countries, mobile layout |
| Authentication and authorization | `AuthService.js`, `AuthController.js`, owner-only rules |
| Sophistication | `GameEngine`, `BattleEngine`, `PopulationModel`, NPC strategies, missile and nuke animation, live population |
| AI application | `ai/`, `functions/` |
| Evidence of effort | tests, `docs/screenshots/`, this README |

## 10. Assumptions and known limits

- The country list is a 41-country built-in sample with rounded populations.
- Conquest bonus uses the conquered country's base soldier value. If you are eliminated the game ends.
- Population is a live display; it does not change battle odds.
- The NPCs run in the owner's browser while the game page is open. Closing the page pauses the game until it is reopened.
- Callsigns are not checked for uniqueness.
- The Firestore rules and the Cloud Function have been reviewed and the function is unit-tested, but they were not exercised against a live Firebase project during development; the browser test uses a fake Firebase.
