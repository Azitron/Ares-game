import { COUNTRIES } from '../../public/js/data/countries.js';
import { GameEngine } from '../../public/js/engine/GameEngine.js';
import { GameFactory } from '../../public/js/engine/GameFactory.js';
import { RulesStrategy } from '../../public/js/engine/NpcStrategy.js';
import { Country } from '../../public/js/models/Country.js';
import { Game } from '../../public/js/models/Game.js';
import { Player } from '../../public/js/models/Player.js';
import { FixedClock } from '../../public/js/utils/clock.js';
import { Rng } from '../../public/js/utils/rng.js';

export const GAME_ID = 'abcdefghij0123456789';

export const makeFactory = (seed = 1, clock = new FixedClock(1_000_000)) =>
  new GameFactory({ catalogue: COUNTRIES, rng: Rng.seeded(seed), clock });

export const makeGame = (seed = 1, country = 'South Africa') =>
  makeFactory(seed).create({ id: GAME_ID, ownerUid: 'uid-1', ownerName: 'tester', playerCountry: country });

export const stubCommentator = {
  battle: async ({ attacker, defender }) => `${attacker.name} vs ${defender.name}`,
  conquest: async ({ attacker, defender }) => `${attacker.name} takes ${defender.name}`,
};

export const makeEngine = (game, { seed = 7, askCount = async (_m, max) => max, clock = new FixedClock(2_000_000) } = {}) => {
  const changes = [];
  const errors = [];
  const engine = new GameEngine({
    game,
    rng: Rng.seeded(seed),
    clock,
    commentator: stubCommentator,
    strategy: new RulesStrategy(),
    prompts: { askCount },
    notify: () => changes.push(1),
    onError: (error) => errors.push(error),
    sleep: async () => {},
    pacing: { normalMs: 0, fastMs: 0 },
  });
  return { engine, changes, errors, clock };
};

export const makeCustomGame = ({ soldiers, owners, turn = 0, alive }) => {
  const countries = COUNTRIES.slice(0, 10).map((entry, i) =>
    new Country({ name: entry.name, flag: entry.flag, base: 4, soldiers: soldiers[i], owner: owners[i], population: entry.population, stamp: 0 }),
  );
  const players = COUNTRIES.slice(0, 10).map((entry, i) => new Player({ name: entry.name, alive: alive ? alive[i] : true }));
  return new Game({ id: GAME_ID, ownerUid: 'uid-1', ownerName: 'tester', created: 0, countries, players, turn });
};
