const APP = `
export const initializeApp = (config) => ({ config });
`;

const AUTH = `
const USERS = '__mock_users';
const SESSION = '__mock_session';
const read = (key, fallback) => JSON.parse(localStorage.getItem(key) || fallback);
const listeners = new Set();
const auth = {
  get currentUser() {
    const uid = localStorage.getItem(SESSION);
    if (!uid) return null;
    const record = Object.values(read(USERS, '{}')).find((u) => u.uid === uid);
    return record ? { uid, email: record.email, displayName: record.displayName, getIdToken: async () => 'mock-token-' + uid } : null;
  },
};
const fail = (code) => Object.assign(new Error(code), { code });
const emit = () => listeners.forEach((cb) => cb(auth.currentUser));
export const getAuth = () => auth;
export const onAuthStateChanged = (_auth, cb) => {
  listeners.add(cb);
  setTimeout(() => cb(auth.currentUser), 0);
  return () => listeners.delete(cb);
};
export const createUserWithEmailAndPassword = async (_auth, email, password) => {
  const users = read(USERS, '{}');
  if (users[email]) throw fail('auth/email-already-in-use');
  const uid = 'uid_' + Math.random().toString(36).slice(2, 10);
  users[email] = { uid, email, password, displayName: null };
  localStorage.setItem(USERS, JSON.stringify(users));
  localStorage.setItem(SESSION, uid);
  emit();
  return { user: { uid, email } };
};
export const signInWithEmailAndPassword = async (_auth, email, password) => {
  const record = read(USERS, '{}')[email];
  if (!record || record.password !== password) throw fail('auth/invalid-credential');
  localStorage.setItem(SESSION, record.uid);
  emit();
  return { user: { uid: record.uid, email } };
};
export const updateProfile = async (user, profile) => {
  const users = read(USERS, '{}');
  const record = Object.values(users).find((u) => u.uid === user.uid);
  Object.assign(record, profile);
  localStorage.setItem(USERS, JSON.stringify(users));
};
export const signOut = async () => {
  localStorage.removeItem(SESSION);
  emit();
};
`;

const FIRESTORE = `
const DB = '__mock_db';
const read = () => JSON.parse(localStorage.getItem(DB) || '{}');
const write = (db) => localStorage.setItem(DB, JSON.stringify(db));
const snap = (path) => {
  const value = read()[path];
  return { exists: () => value !== undefined, data: () => (value === undefined ? undefined : JSON.parse(JSON.stringify(value))) };
};
export const getFirestore = () => ({});
export const collection = (_db, name) => ({ name });
export const doc = (a, b, c) => {
  if (c !== undefined) return { path: b + '/' + c, id: c };
  const id = Array.from({ length: 20 }, () => 'abcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(Math.random() * 36)]).join('');
  return { path: a.name + '/' + id, id };
};
export const setDoc = async (ref, data) => {
  const db = read();
  db[ref.path] = JSON.parse(JSON.stringify(data));
  write(db);
};
export const getDoc = async (ref) => snap(ref.path);
export const deleteDoc = async (ref) => {
  const db = read();
  delete db[ref.path];
  write(db);
};
export const where = (field, op, value) => ({ kind: 'where', field, op, value });
export const orderBy = (field, dir) => ({ kind: 'order', field, dir });
export const limit = (n) => ({ kind: 'limit', n });
export const query = (col, ...rules) => ({ col, rules });
export const getDocs = async (q) => {
  let rows = Object.entries(read()).filter(([path]) => path.startsWith(q.col.name + '/')).map(([, v]) => v);
  q.rules.forEach((r) => {
    if (r.kind === 'where') rows = rows.filter((row) => row[r.field] === r.value);
    if (r.kind === 'order') rows.sort((a, b) => (r.dir === 'desc' ? b[r.field] - a[r.field] : a[r.field] - b[r.field]));
    if (r.kind === 'limit') rows = rows.slice(0, r.n);
  });
  return { docs: rows.map((row) => ({ data: () => JSON.parse(JSON.stringify(row)) })) };
};
export const onSnapshot = (ref, next) => {
  let last = null;
  const push = () => {
    const s = snap(ref.path);
    const key = JSON.stringify(s.data());
    if (key !== last) {
      last = key;
      next(s);
    }
  };
  push();
  const timer = setInterval(push, 400);
  return () => clearInterval(timer);
};
`;

export const MOCK_MODULES = Object.freeze({
  'firebase-app.js': APP,
  'firebase-auth.js': AUTH,
  'firebase-firestore.js': FIRESTORE,
});
