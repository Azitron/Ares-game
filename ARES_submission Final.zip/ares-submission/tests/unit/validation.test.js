import assert from 'node:assert/strict';
import { test } from 'node:test';
import { ValidationError, friendlyError } from '../../public/js/utils/errors.js';
import { clampCount, sanitiseCallsign, validateCallsign, validateCount, validateEmail, validateGameId, validateLoginPassword, validateNewPassword } from '../../public/js/utils/validation.js';

test('email validation trims and rejects bad input', () => {
  assert.equal(validateEmail('  a@b.co  '), 'a@b.co');
  ['', 'nope', 'a@b', 'a b@c.com', `${'x'.repeat(130)}@b.com`].forEach((v) => assert.throws(() => validateEmail(v), ValidationError));
});

test('new passwords need length, a letter and a number', () => {
  assert.equal(validateNewPassword('abcdefg1'), 'abcdefg1');
  ['short1', 'abcdefgh', '12345678', 'x'.repeat(65) + '1'].forEach((v) => assert.throws(() => validateNewPassword(v), ValidationError));
  assert.throws(() => validateLoginPassword(''), ValidationError);
});

test('callsigns allow only 3-20 safe characters', () => {
  assert.equal(validateCallsign(' Neo_01 '), 'Neo_01');
  ['ab', 'a'.repeat(21), 'bad name', '<b>x</b>', 'x;drop'].forEach((v) => assert.throws(() => validateCallsign(v), ValidationError));
  assert.equal(sanitiseCallsign('a.b@c'), 'abc');
  assert.equal(sanitiseCallsign('..'), 'operator');
});

test('game ids must be 20 alphanumerics', () => {
  assert.equal(validateGameId('abcdefghij0123456789'), 'abcdefghij0123456789');
  ['', 'short', '../../etc/passwd', 'abcdefghij012345678!'].forEach((v) => assert.throws(() => validateGameId(v), ValidationError));
});

test('counts are validated and clamped', () => {
  assert.equal(validateCount('3', 0, 5), 3);
  assert.throws(() => validateCount(6, 0, 5), ValidationError);
  assert.throws(() => validateCount(1.5, 0, 5), ValidationError);
  assert.equal(clampCount(99, 0, 5), 5);
  assert.equal(clampCount(-4, 0, 5), 0);
  assert.equal(clampCount('x', 0, 5), 0);
});

test('friendly errors map Firebase codes', () => {
  assert.match(friendlyError({ code: 'auth/invalid-credential' }), /Create account/);
  assert.match(friendlyError({ code: 'permission-denied' }), /rules/);
  assert.equal(friendlyError(new Error('boom')), 'boom');
});
