import assert from 'node:assert/strict';
import { test } from 'node:test';
import { COUNTRIES, findCountry } from '../../public/js/data/countries.js';
import { attackEdge, conquestGarrison, diceCount, reinforcementsFor, soldiersForPopulation } from '../../public/js/engine/Rules.js';

test('population maps to soldiers using the exam table', () => {
  const cases = [[0.0008, 1], [5, 1], [5.1, 2], [10, 2], [25, 3], [50, 4], [75, 5], [100, 6], [125, 7], [150, 8], [150.1, 9], [1430, 9]];
  cases.forEach(([population, expected]) => assert.equal(soldiersForPopulation(population), expected, `${population}M`));
});

test('conquest garrison is max(2, floor(base / 2))', () => {
  assert.equal(conquestGarrison(9), 4);
  assert.equal(conquestGarrison(1), 2);
  assert.equal(conquestGarrison(4), 2);
  assert.equal(conquestGarrison(7), 3);
});

test('dice count is min(attacker - 1, defender) and never negative', () => {
  assert.equal(diceCount(5, 3), 3);
  assert.equal(diceCount(3, 9), 2);
  assert.equal(diceCount(1, 5), 0);
  assert.equal(diceCount(0, 0), 0);
});

test('reinforcements and edge helpers', () => {
  assert.equal(reinforcementsFor(3), 6);
  assert.equal(attackEdge(6, 3), 2);
});

test('country catalogue is clean and includes South Africa', () => {
  assert.ok(COUNTRIES.length >= 40);
  assert.equal(new Set(COUNTRIES.map((c) => c.name)).size, COUNTRIES.length);
  COUNTRIES.forEach((c) => {
    assert.ok(c.population > 0 && Math.abs(c.lat) <= 90 && Math.abs(c.lon) <= 180, c.name);
    assert.ok(Object.isFrozen(c));
  });
  assert.equal(findCountry('South Africa').flag, '🇿🇦');
  assert.equal(findCountry('Atlantis'), null);
});
