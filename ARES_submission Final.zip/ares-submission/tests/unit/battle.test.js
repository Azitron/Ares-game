import assert from 'node:assert/strict';
import { test } from 'node:test';
import { BattleEngine } from '../../public/js/engine/BattleEngine.js';
import { Rng } from '../../public/js/utils/rng.js';

const scripted = (values) => {
  let i = 0;
  return new Rng(() => (values[i++ % values.length] - 0.5) / 6);
};

test('higher die wins each pair and ties kill nobody', () => {
  const rng = scripted([6, 1, 3, 5, 5, 2]);
  const result = new BattleEngine(rng).resolve(4, 3);
  assert.deepEqual(result.attackerDice, [6, 1, 3]);
  assert.deepEqual(result.defenderDice, [5, 5, 2]);
  assert.equal(result.defenderLosses, 2);
  assert.equal(result.attackerLosses, 1);
});

test('equal dice cause no losses', () => {
  const result = new BattleEngine(scripted([4, 4])).resolve(2, 5);
  assert.deepEqual([result.attackerLosses, result.defenderLosses], [0, 0]);
});

test('a one-soldier attacker rolls nothing', () => {
  const result = new BattleEngine(Rng.seeded(3)).resolve(1, 4);
  assert.deepEqual(result.attackerDice, []);
});

test('dice are always 1 to 6 and losses never exceed dice count', () => {
  const engine = new BattleEngine(Rng.seeded(99));
  for (let i = 0; i < 500; i += 1) {
    const result = engine.resolve(1 + (i % 9), 1 + ((i * 7) % 9));
    [...result.attackerDice, ...result.defenderDice].forEach((d) => assert.ok(d >= 1 && d <= 6));
    assert.equal(result.attackerLosses + result.defenderLosses <= result.attackerDice.length, true);
  }
});
