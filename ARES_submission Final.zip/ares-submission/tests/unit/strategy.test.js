import assert from 'node:assert/strict';
import { test } from 'node:test';
import { AiAssistedStrategy, RulesStrategy } from '../../public/js/engine/NpcStrategy.js';
import { makeCustomGame } from '../helpers/builders.js';

const OWNERS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

test('rules strategy picks the best dice edge and explains why', async () => {
  const game = makeCustomGame({ soldiers: [2, 9, 2, 6, 3, 3, 3, 3, 3, 3], owners: OWNERS });
  const choice = await new RulesStrategy().chooseAttack(game, 1);
  assert.equal(choice.from.name, game.countries[1].name);
  assert.equal(choice.to.name, game.countries[0].name);
  assert.match(choice.why, /Dice edge: 8 attackers vs 2 defenders/);
});

test('rules strategy holds when no target gives an edge', async () => {
  const game = makeCustomGame({ soldiers: [1, 1, 9, 9, 9, 9, 9, 9, 9, 9], owners: OWNERS });
  assert.equal(await new RulesStrategy().chooseAttack(game, 1), null);
});

test('reinforcements go to the biggest garrison and retreat triggers on bad odds', () => {
  const game = makeCustomGame({ soldiers: [5, 3, 3, 3, 3, 3, 3, 3, 3, 3], owners: [0, 0, 2, 3, 4, 5, 6, 7, 8, 9] });
  const strategy = new RulesStrategy();
  assert.equal(strategy.chooseReinforcement(game, 0), game.countries[0]);
  assert.equal(strategy.shouldRetreat({ soldiers: 3 }, { soldiers: 5 }), true);
  assert.equal(strategy.shouldRetreat({ soldiers: 9 }, { soldiers: 5 }), false);
});

test('AI-assisted strategy accepts only legal AI choices', async () => {
  const game = makeCustomGame({ soldiers: [2, 9, 2, 6, 3, 3, 3, 3, 3, 3], owners: OWNERS });
  const names = game.countries.map((c) => c.name);
  const ask = (reply) => new AiAssistedStrategy({ fallback: new RulesStrategy(), ai: { request: async () => reply } });
  const good = await ask({ from: names[1], to: names[3], why: 'weak flank' }).chooseAttack(game, 1);
  assert.equal(good.to.name, names[3]);
  assert.match(good.why, /^AI: weak flank/);
  const ownTarget = await ask({ from: names[1], to: names[1], why: 'x' }).chooseAttack(game, 1);
  assert.equal(ownTarget.to.name, names[0]);
  const notMine = await ask({ from: names[2], to: names[3], why: 'x' }).chooseAttack(game, 1);
  assert.equal(notMine.from.name, names[1]);
  const offline = await ask(null).chooseAttack(game, 1);
  assert.equal(offline.from.name, names[1]);
  const hold = await ask({ from: null, why: 'wait' }).chooseAttack(game, 1);
  assert.equal(hold.from.name, names[1]);
});
