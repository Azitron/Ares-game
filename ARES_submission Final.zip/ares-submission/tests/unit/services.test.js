import assert from 'node:assert/strict';
import { test } from 'node:test';
import { AI_STATUS, AiClient } from '../../public/js/ai/AiClient.js';
import { Commentator } from '../../public/js/ai/Commentator.js';
import { AuthService } from '../../public/js/services/AuthService.js';
import { GameRepository } from '../../public/js/services/GameRepository.js';
import { FixedClock } from '../../public/js/utils/clock.js';
import { ValidationError } from '../../public/js/utils/errors.js';
import { Rng } from '../../public/js/utils/rng.js';
import { GAME_ID, makeGame } from '../helpers/builders.js';

const fakeFirestore = () => {
  const store = new Map();
  const sdk = {
    collection: (_db, name) => ({ name }),
    doc: (a, b, c) => (c ? { path: `${b}/${c}`, id: c } : { path: `auto/${GAME_ID}`, id: GAME_ID }),
    setDoc: async (ref, data) => store.set(ref.path, structuredClone(data)),
    getDoc: async (ref) => ({ exists: () => store.has(ref.path), data: () => structuredClone(store.get(ref.path)) }),
    deleteDoc: async (ref) => store.delete(ref.path),
    where: (field, op, value) => ({ field, op, value }),
    orderBy: (field) => ({ orderBy: field }),
    limit: (n) => ({ limit: n }),
    query: (col, ...rules) => ({ col, rules }),
    getDocs: async (q) => {
      let rows = [...store.entries()].filter(([path]) => path.startsWith('games/')).map(([, v]) => v);
      q.rules.forEach((r) => {
        if (r.field) rows = rows.filter((row) => row[r.field] === r.value);
        if (r.orderBy) rows.sort((a, b) => b[r.orderBy] - a[r.orderBy]);
        if (r.limit) rows = rows.slice(0, r.limit);
      });
      return { docs: rows.map((row) => ({ data: () => row })) };
    },
    onSnapshot: (ref, next) => {
      next({ exists: () => store.has(ref.path), data: () => store.get(ref.path) });
      return () => {};
    },
  };
  return { sdk, store };
};

test('repository saves valid games, loads them back and refuses invalid ones', async () => {
  const { sdk, store } = fakeFirestore();
  const repo = new GameRepository({ sdk, db: {} });
  const game = makeGame(4);
  await repo.save(game);
  assert.ok(store.has(`games/${GAME_ID}`));
  const loaded = await repo.load(GAME_ID);
  assert.deepEqual(loaded.toJSON(), game.toJSON());
  assert.equal(await repo.load('zzzzzzzzzz0123456789'), null);
  await assert.rejects(() => repo.load('../bad'), ValidationError);
  const broken = makeGame(4);
  broken.countries[0].removeSoldiers(0);
  const doc = { ...broken.toJSON(), phase: 'hack' };
  store.set('games/x', doc);
  await assert.rejects(() => repo.save({ toJSON: () => doc }), ValidationError);
});

test('repository lists by owner, lists public newest first, and deletes', async () => {
  const { sdk } = fakeFirestore();
  const repo = new GameRepository({ sdk, db: {} });
  const docs = [['aaaaaaaaaa0000000001', 'u1', 10], ['aaaaaaaaaa0000000002', 'u2', 30], ['aaaaaaaaaa0000000003', 'u1', 20]];
  for (const [id, owner, created] of docs) {
    const json = { ...makeGame(2).toJSON(), id, owner, created };
    await sdk.setDoc({ path: `games/${id}` }, json);
  }
  assert.deepEqual((await repo.listByOwner('u1')).map((g) => g.id), ['aaaaaaaaaa0000000003', 'aaaaaaaaaa0000000001']);
  assert.deepEqual((await repo.listPublic(2)).map((g) => g.id), ['aaaaaaaaaa0000000002', 'aaaaaaaaaa0000000003']);
  await repo.remove('aaaaaaaaaa0000000002');
  assert.equal((await repo.listPublic(5)).length, 2);
  assert.equal(repo.newId(), GAME_ID);
});

test('auth service validates input before calling Firebase', async () => {
  const calls = [];
  const sdk = {
    onAuthStateChanged: () => () => {},
    signInWithEmailAndPassword: async (...a) => calls.push(['in', a[1]]),
    createUserWithEmailAndPassword: async (_a, email) => {
      calls.push(['create', email]);
      return { user: { uid: 'u9' } };
    },
    updateProfile: async (user, profile) => Object.assign(auth.currentUser, profile),
    signOut: async () => calls.push(['out']),
  };
  const auth = { currentUser: { uid: 'u9', email: 'n@x.com', displayName: null, getIdToken: async () => 'tok' } };
  const service = new AuthService({ sdk, auth });
  await assert.rejects(() => service.signIn({ email: 'bad', password: 'x' }), ValidationError);
  await assert.rejects(() => service.register({ callsign: 'ab', email: 'n@x.com', password: 'abcdefg1' }), ValidationError);
  await assert.rejects(() => service.register({ callsign: 'Neo', email: 'n@x.com', password: 'weak' }), ValidationError);
  assert.deepEqual(calls, []);
  const seen = [];
  service.onChange((u) => seen.push(u?.callsign));
  const user = await service.register({ callsign: 'Neo', email: ' n@x.com ', password: 'abcdefg1' });
  assert.equal(user.callsign, 'Neo');
  assert.deepEqual(calls, [['create', 'n@x.com']]);
  assert.deepEqual(seen, ['Neo']);
  assert.equal(await service.token(), 'tok');
});

const response = (ok, body) => ({ ok, status: ok ? 200 : 500, json: async () => body });

test('AI client is disabled without an https endpoint', async () => {
  const client = new AiClient({ endpoint: 'PASTE_FUNCTION_URL_HERE', getToken: async () => 't', clock: new FixedClock() });
  assert.equal(client.status, AI_STATUS.TEMPLATES);
  assert.equal(await client.request({}), null);
});

test('AI client reports live status, then trips a cooldown after a failure', async () => {
  const clock = new FixedClock(1000);
  let mode = 'ok';
  let calls = 0;
  const fetchFn = async (url, init) => {
    calls += 1;
    assert.equal(init.headers.Authorization, 'Bearer tok');
    if (mode === 'throw') throw new Error('network');
    return response(mode === 'ok', { text: 'hi' });
  };
  const client = new AiClient({ endpoint: 'https://f.example/x', getToken: async () => 'tok', fetchFn, clock, cooldownMs: 30000 });
  assert.equal(client.status, AI_STATUS.READY);
  assert.deepEqual(await client.request({ type: 'commentary' }), { text: 'hi' });
  assert.equal(client.status, AI_STATUS.LIVE);
  mode = 'throw';
  assert.equal(await client.request({}), null);
  assert.equal(client.status, AI_STATUS.OFFLINE);
  mode = 'ok';
  const before = calls;
  assert.equal(await client.request({}), null);
  assert.equal(calls, before);
  clock.advance(31000);
  assert.deepEqual(await client.request({}), { text: 'hi' });
});

test('AI client returns null when the user is not signed in', async () => {
  const client = new AiClient({ endpoint: 'https://f.example/x', getToken: async () => null, fetchFn: async () => response(true, {}), clock: new FixedClock() });
  assert.equal(await client.request({}), null);
});

test('commentator uses AI text, falls back to templates, and skips AI for fast battles', async () => {
  const calls = [];
  const ai = { status: 'live', request: async (body) => (calls.push(body), calls.length === 1 ? { text: 'AI line' } : null) };
  const commentator = new Commentator({ ai, rng: Rng.seeded(1) });
  const a = { name: 'Japan' };
  const b = { name: 'Cuba' };
  const result = { attackerDice: [6], defenderDice: [1], attackerLosses: 0, defenderLosses: 1 };
  assert.equal(await commentator.battle({ attacker: a, defender: b, result, fast: false }), 'AI line');
  assert.match(calls[0].event, /Japan \[6\] vs Cuba \[1\] -> -0\/-1/);
  assert.match(await commentator.battle({ attacker: a, defender: b, result, fast: false }), /Japan|Cuba/);
  const before = calls.length;
  await commentator.battle({ attacker: a, defender: b, result, fast: true });
  assert.equal(calls.length, before);
  assert.match(await commentator.conquest({ attacker: a, defender: b, garrison: 2, fast: true }), /Cuba goes dark/);
});
