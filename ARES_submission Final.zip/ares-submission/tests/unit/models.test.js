import assert from 'node:assert/strict';
import { test } from 'node:test';
import { Country } from '../../public/js/models/Country.js';
import { Game } from '../../public/js/models/Game.js';
import { GameSummary } from '../../public/js/models/GameSummary.js';
import { SessionUser } from '../../public/js/models/SessionUser.js';
import { RuleError, ValidationError } from '../../public/js/utils/errors.js';
import { assertGameDocument } from '../../public/js/utils/validation.js';
import { makeCustomGame, makeGame } from '../helpers/builders.js';

test('Country encapsulates its state and rejects invalid values', () => {
  const country = new Country({ name: 'Peru', flag: 'P', base: 3, owner: 2, population: 34, stamp: 1 });
  assert.equal(country.soldiers, 3);
  assert.throws(() => country.addSoldiers(-1), RuleError);
  assert.throws(() => country.addSoldiers(1.5), RuleError);
  country.removeSoldiers(10);
  assert.equal(country.soldiers, 0);
  assert.throws(() => new Country({ name: '', base: 1, owner: 0, population: 1, stamp: 0 }), RuleError);
  assert.throws(() => new Country({ name: 'X', base: 1, owner: 12, population: 1, stamp: 0 }), RuleError);
  assert.throws(() => new Country({ name: 'X', base: 1, owner: 0, population: -5, stamp: 0 }), RuleError);
  assert.equal('soldiers' in Object.getOwnPropertyDescriptors(country), false);
});

test('capture replaces owner and garrison', () => {
  const country = new Country({ name: 'Peru', flag: 'P', base: 3, owner: 2, population: 34, stamp: 1 });
  country.capture(0, 2);
  assert.deepEqual([country.owner, country.soldiers], [0, 2]);
});

test('Game serialises, validates and restores without loss', () => {
  const game = makeGame(11);
  game.appendLog({ i: 0, t: 'hello', w: '' });
  const json = JSON.parse(JSON.stringify(game.toJSON()));
  assertGameDocument(json);
  const restored = Game.fromJSON(json);
  assert.deepEqual(restored.toJSON(), game.toJSON());
});

test('Game needs ten countries and ten players', () => {
  assert.throws(() => new Game({ id: 'x', ownerUid: 'u', ownerName: 'n', created: 0, countries: [], players: [] }), RuleError);
});

test('advanceTurn skips eliminated players and grants +2 per country from round 2', () => {
  const alive = [true, true, false, true, true, true, true, true, true, true];
  const game = makeCustomGame({ soldiers: Array(10).fill(3), owners: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], turn: 1, alive });
  game.advanceTurn();
  assert.equal(game.turn, 3);
  assert.equal(game.pool, 0);
  assert.equal(game.phase, 'act');
  for (let i = 0; i < 8; i += 1) game.advanceTurn();
  assert.equal(game.turn, 1);
  assert.equal(game.pool, 2);
  assert.equal(game.phase, 'reinforce');
  assert.equal(game.round, 2);
});

test('the log is capped at 80 entries', () => {
  const game = makeGame(2);
  for (let i = 0; i < 120; i += 1) game.appendLog({ i: 0, t: String(i), w: '' });
  assert.equal(game.log.length, 80);
  assert.equal(game.log[0].t, '40');
});

test('invalid game documents are rejected', () => {
  const base = makeGame(3).toJSON();
  const bad = [
    { ...base, id: 'short' },
    { ...base, owner: '' },
    { ...base, countries: base.countries.slice(1) },
    { ...base, phase: 'dance' },
    { ...base, winner: 5 },
    { ...base, countries: base.countries.map((c, i) => (i ? c : { ...c, soldiers: -1 })) },
    { ...base, log: Array(81).fill({ i: 0, t: '', w: '' }) },
  ];
  bad.forEach((doc) => assert.throws(() => assertGameDocument(doc), ValidationError));
  assert.throws(() => assertGameDocument(null), ValidationError);
});

test('GameSummary derives status and matches searches', () => {
  const live = GameSummary.fromDocument({ id: 'a', ownerName: 'Neo', players: [{ name: 'Japan' }], round: 3, created: 5, winner: null });
  const won = GameSummary.fromDocument({ id: 'b', ownerName: 'Trinity', players: [{ name: 'Cuba' }], winner: 0, created: 9 });
  const lost = GameSummary.fromDocument({ id: 'c', ownerName: 'Morpheus', players: [{ name: 'Chile' }], winner: -1, created: 1 });
  assert.deepEqual([live.status, won.status, lost.status], ['live', 'won', 'lost']);
  assert.ok(live.matches('jap', 'all') && live.matches('NEO', 'live'));
  assert.ok(!live.matches('cuba', 'all') && !live.matches('', 'won'));
  assert.equal(live.flag, '🇯🇵');
  assert.deepEqual([live, won, lost].sort(GameSummary.compare).map((g) => g.id), ['b', 'a', 'c']);
});

test('SessionUser builds a safe callsign from the Firebase user', () => {
  assert.equal(SessionUser.fromFirebase(null), null);
  assert.equal(SessionUser.fromFirebase({ uid: '1', email: 'a.b+c@x.com', displayName: null }).callsign, 'abc');
  assert.equal(SessionUser.fromFirebase({ uid: '1', email: 'q@x.com', displayName: 'Neo_1' }).callsign, 'Neo_1');
  assert.equal(SessionUser.fromFirebase({ uid: '1', email: 'q@x.com', displayName: '<script>' }).callsign, 'script');
});
