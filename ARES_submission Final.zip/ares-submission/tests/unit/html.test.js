import assert from 'node:assert/strict';
import { test } from 'node:test';
import { escapeHtml, html, raw } from '../../public/js/utils/html.js';
import { formatCompactPeople, formatMillions, formatPeople } from '../../public/js/utils/format.js';
import { Rng } from '../../public/js/utils/rng.js';

test('html template escapes interpolated values', () => {
  const evil = '<img src=x onerror=alert(1)>"\'&';
  const out = String(html`<p title="${evil}">${evil}</p>`);
  assert.ok(!out.includes('<img'));
  assert.ok(out.includes('&lt;img') && out.includes('&quot;') && out.includes('&#39;') && out.includes('&amp;'));
});

test('nested templates, arrays and falsy values render predictably', () => {
  assert.equal(String(html`<ul>${[1, 2].map((n) => html`<li>${n}</li>`)}</ul>`), '<ul><li>1</li><li>2</li></ul>');
  assert.equal(String(html`${false}${null}${undefined}${0}`), '0');
  assert.equal(String(html`${raw('<b>ok</b>')}`), '<b>ok</b>');
  assert.equal(escapeHtml(null), '');
});

test('number formatting', () => {
  assert.equal(formatMillions(1430), '1.43B');
  assert.equal(formatMillions(60), '60M');
  assert.equal(formatMillions(5.5), '5.5M');
  assert.equal(formatMillions(0.0008), '0.8K');
  assert.equal(formatPeople(1.5), '1,500,000');
  assert.equal(formatCompactPeople(0.25), '250K');
});

test('seeded rng is reproducible and shuffle keeps every item', () => {
  const a = Rng.seeded(42);
  const b = Rng.seeded(42);
  assert.deepEqual([a.int(6), a.int(6), a.int(6)], [b.int(6), b.int(6), b.int(6)]);
  const items = [1, 2, 3, 4, 5, 6, 7];
  assert.deepEqual([...Rng.seeded(1).shuffle(items)].sort(), items);
  assert.deepEqual(items, [1, 2, 3, 4, 5, 6, 7]);
});
