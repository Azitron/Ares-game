import assert from 'node:assert/strict';
import { test } from 'node:test';
import { POPULATION } from '../../public/js/config/rules.js';
import { PopulationModel } from '../../public/js/engine/PopulationModel.js';
import { FixedClock } from '../../public/js/utils/clock.js';
import { formatGameDate } from '../../public/js/utils/format.js';
import { makeFactory } from '../helpers/builders.js';

const setup = () => {
  const clock = new FixedClock(1_000_000);
  const game = makeFactory(1, clock).create({ id: 'abcdefghij0123456789', ownerUid: 'u', ownerName: 'tester', playerCountry: 'India' });
  return { clock, game, model: new PopulationModel(game, clock) };
};

test('population grows with time and is capped', () => {
  const { clock, game, model } = setup();
  const india = game.countries[0];
  assert.equal(model.current(india), 1430);
  clock.advance(10_000);
  assert.ok(Math.abs(model.current(india) - 1430 * (1 + POPULATION.growthPerSecond * 10)) < 1e-9);
  clock.advance(10_000_000);
  assert.ok(Math.abs(model.current(india) - 1430 * (1 + POPULATION.growthPerSecond * POPULATION.growthCapSeconds)) < 1e-9);
});

test('apply shrinks the population and restamps it', () => {
  const { clock, game, model } = setup();
  const india = game.countries[0];
  clock.advance(5_000);
  const before = model.current(india);
  model.apply(india, 1 - POPULATION.battleLoss * 2);
  assert.ok(Math.abs(india.population - before * 0.98) < 1e-5);
  assert.equal(india.stamp, clock.now());
});

test('population freezes when the game has ended', () => {
  const { clock, game, model } = setup();
  clock.advance(3_000);
  game.declareWinner(0, clock.now());
  const frozen = model.current(game.countries[1]);
  clock.advance(60_000);
  assert.equal(model.current(game.countries[1]), frozen);
});

test('game clock runs one game day per real second and is capped at one hour', () => {
  const { clock, game, model } = setup();
  const start = model.gameTime();
  clock.advance(2_000);
  assert.equal(model.gameTime() - start, 2 * 86_400_000);
  clock.advance(10 * 3_600_000);
  assert.equal(model.gameTime() - start, 3_600_000 * 86_400);
  assert.match(formatGameDate(model.gameTime()), /^\d{1,2} [A-Z]{3} \d{4}$/);
});

test('total sums the live populations', () => {
  const { game, model } = setup();
  const total = model.total(game.countries.slice(0, 2));
  assert.equal(total, game.countries[0].population + game.countries[1].population);
});
