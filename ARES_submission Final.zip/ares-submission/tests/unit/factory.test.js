import assert from 'node:assert/strict';
import { test } from 'node:test';
import { COUNTRIES } from '../../public/js/data/countries.js';
import { RuleError } from '../../public/js/utils/errors.js';
import { soldiersForPopulation } from '../../public/js/engine/Rules.js';
import { makeFactory, makeGame } from '../helpers/builders.js';

test('every game has 10 unique countries with the player first', () => {
  for (let seed = 1; seed <= 60; seed += 1) {
    const game = makeGame(seed, 'Japan');
    const names = game.countries.map((c) => c.name);
    assert.equal(names.length, 10);
    assert.equal(new Set(names).size, 10);
    assert.equal(names[0], 'Japan');
    game.countries.forEach((c, i) => assert.equal(c.owner, i));
  }
});

test('South Africa is in every game, whichever country the player picks', () => {
  for (let seed = 1; seed <= 200; seed += 1) {
    COUNTRIES.filter((_, i) => i % 7 === seed % 7).forEach((entry) => {
      const game = makeGame(seed, entry.name);
      assert.ok(game.countries.some((c) => c.name === 'South Africa'), `${entry.name} seed ${seed}`);
    });
  }
});

test('starting soldiers follow the population table', () => {
  const game = makeGame(5, 'India');
  game.countries.forEach((c) => {
    const entry = COUNTRIES.find((x) => x.name === c.name);
    assert.equal(c.soldiers, soldiersForPopulation(entry.population));
    assert.equal(c.base, c.soldiers);
  });
});

test('unknown countries are rejected', () => {
  assert.throws(() => makeFactory().create({ id: 'x', ownerUid: 'u', ownerName: 'n', playerCountry: 'Atlantis' }), RuleError);
});

test('starting turn is random but valid and the log starts empty', () => {
  const turns = new Set();
  for (let seed = 1; seed <= 80; seed += 1) {
    const game = makeGame(seed);
    assert.ok(game.turn >= 0 && game.turn < 10);
    assert.equal(game.log.length, 0);
    assert.equal(game.round, 1);
    turns.add(game.turn);
  }
  assert.ok(turns.size > 4);
});
