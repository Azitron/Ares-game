import assert from 'node:assert/strict';
import { test } from 'node:test';
import { RuleError } from '../../public/js/utils/errors.js';
import { Rng } from '../../public/js/utils/rng.js';
import { makeCustomGame, makeEngine, makeGame } from '../helpers/builders.js';

const OWNERS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

test('only the human can act on their own turn, and only with legal targets', () => {
  const game = makeCustomGame({ soldiers: [5, 3, 3, 3, 3, 3, 3, 3, 3, 3], owners: OWNERS, turn: 1 });
  const { engine } = makeEngine(game);
  assert.throws(() => engine.startAttack(0, 1), /not your turn/);
  const mine = makeCustomGame({ soldiers: [5, 3, 3, 1, 3, 3, 3, 3, 3, 3], owners: [0, 1, 2, 0, 4, 5, 6, 7, 8, 9], turn: 0 });
  const second = makeEngine(mine).engine;
  assert.throws(() => second.startAttack(1, 2), /own countries/);
  assert.throws(() => second.startAttack(0, 3), /enemy/);
  assert.throws(() => second.startAttack(3, 1), /at least 2 soldiers/);
  second.startAttack(0, 1);
  assert.deepEqual(mine.attack, { f: 0, t: 1 });
  assert.throws(() => second.startAttack(0, 2), /already in progress/);
});

test('rolling to a conquest transfers ownership, awards the bonus and ends the turn', async () => {
  const game = makeCustomGame({ soldiers: [9, 1, 3, 3, 3, 3, 3, 3, 3, 3], owners: OWNERS, turn: 0 });
  const { engine, errors } = makeEngine(game, { askCount: async () => 2 });
  engine.startAttack(0, 1);
  for (let i = 0; i < 20 && game.countries[1].owner === 1; i += 1) await engine.roll();
  const target = game.countries[1];
  assert.equal(target.owner, 0);
  assert.ok(target.soldiers >= 2);
  assert.equal(game.players[1].alive, false);
  assert.notEqual(game.turn, 0);
  assert.ok(game.log.some((entry) => /Conquest bonus: max\(2, ⌊4\/2⌋\) = 2/.test(entry.w)));
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.deepEqual(errors, []);
});

test('ties kill nobody and a lone attacker cannot roll', async () => {
  const game = makeCustomGame({ soldiers: [2, 5, 3, 3, 3, 3, 3, 3, 3, 3], owners: OWNERS, turn: 0 });
  const { engine } = makeEngine(game);
  engine.startAttack(0, 1);
  await engine.roll();
  const total = game.countries[0].soldiers + game.countries[1].soldiers;
  assert.ok(total >= 5 && total <= 7);
  assert.equal(game.dice.ad.length, 1);
});

test('reinforcements are placed one at a time or all at once', () => {
  const game = makeCustomGame({ soldiers: [3, 3, 3, 3, 3, 3, 3, 3, 3, 3], owners: [0, 0, 2, 3, 4, 5, 6, 7, 8, 9], turn: 0 });
  game.setPool(4);
  game.setPhase('reinforce');
  const { engine } = makeEngine(game);
  assert.throws(() => engine.startAttack(0, 2), /reinforcements/);
  engine.reinforce(0, 1);
  assert.equal(game.countries[0].soldiers, 4);
  assert.equal(game.pool, 3);
  assert.throws(() => engine.reinforce(2, 1), /own countries/);
  assert.throws(() => engine.reinforce(0, 9), /Invalid/);
  engine.reinforce(1, 3);
  assert.equal(game.pool, 0);
  assert.equal(game.phase, 'act');
  assert.throws(() => engine.reinforce(0, 1), /No reinforcements/);
});

test('transfers keep one soldier behind and move the chosen amount', async () => {
  const game = makeCustomGame({ soldiers: [6, 3, 3, 3, 3, 3, 3, 3, 3, 1], owners: [0, 0, 2, 3, 4, 5, 6, 7, 8, 0], turn: 0 });
  const { engine } = makeEngine(game, { askCount: async (_m, max) => { assert.equal(max, 5); return 99; } });
  await engine.transfer(0, 1);
  assert.equal(game.countries[0].soldiers, 1);
  assert.equal(game.countries[1].soldiers, 8);
  await assert.rejects(() => engine.transfer(9, 1), /keep at least one/);
  await assert.rejects(() => engine.transfer(0, 2), /own countries/);
  engine.startAttack(1, 2);
  await assert.rejects(() => engine.transfer(1, 0), /Finish the attack/);
});

test('winning every country ends the game with a nuke finale flag', async () => {
  const soldiers = [60, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  const owners = [0, 0, 0, 0, 0, 0, 0, 0, 0, 9];
  const alive = [true, false, false, false, false, false, false, false, false, true];
  const game = makeCustomGame({ soldiers, owners, turn: 0, alive });
  const { engine } = makeEngine(game, { askCount: async () => 0 });
  engine.startAttack(0, 9);
  for (let i = 0; i < 30 && !game.isOver; i += 1) await engine.roll();
  assert.equal(game.winner, 0);
  assert.equal(game.fx.n, true);
  assert.equal(game.fx.v, true);
  assert.ok(game.end > 0);
  assert.throws(() => engine.startAttack(0, 9), /not your turn/);
});

test('losing your last country ends the game as a defeat', async () => {
  const game = makeCustomGame({ soldiers: [1, 30, 3, 3, 3, 3, 3, 3, 3, 3], owners: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], turn: 1 });
  const { engine } = makeEngine(game);
  await engine.resume();
  assert.equal(game.winner, -1);
  assert.equal(game.fx.v, false);
  assert.equal(game.players[0].alive, false);
});

test('NPC turns run until it is the human turn and never break invariants', async () => {
  for (let seed = 1; seed <= 25; seed += 1) {
    const game = makeGame(seed, 'South Africa');
    const { engine, errors } = makeEngine(game, { seed });
    if (game.turn !== 0) await engine.resume();
    for (let step = 0; step < 40 && !game.isOver; step += 1) {
      if (game.phase === 'reinforce') engine.reinforce(game.countries.findIndex((c) => c.owner === 0), game.pool);
      await engine.fallBack();
      await engine.resume();
    }
    assert.deepEqual(errors, []);
    game.countries.forEach((c) => {
      assert.ok(c.soldiers >= 0 && Number.isInteger(c.soldiers));
      assert.ok(c.owner >= 0 && c.owner < 10);
      assert.ok(c.population > 0);
    });
    game.players.forEach((p, i) => assert.equal(p.alive, game.countriesOf(i).length > 0));
    if (!game.isOver) assert.ok(game.turn === 0 || game.players[game.turn].alive);
  }
});

test('a full game against an aggressive human reaches a decided state', async () => {
  let decided = 0;
  for (let seed = 1; seed <= 12; seed += 1) {
    const game = makeGame(seed, 'India');
    const { engine } = makeEngine(game, { seed: seed * 3, askCount: async (_m, max) => Math.floor(max / 2) });
    if (game.turn !== 0) await engine.resume();
    for (let round = 0; round < 400 && !game.isOver; round += 1) {
      if (game.phase === 'reinforce') {
        const strongest = game.countries.map((c, i) => [c, i]).filter(([c]) => c.owner === 0).sort((a, b) => b[0].soldiers - a[0].soldiers)[0][1];
        engine.reinforce(strongest, game.pool);
      }
      const from = game.countries.map((c, i) => [c, i]).filter(([c]) => c.owner === 0 && c.soldiers > 1).sort((a, b) => b[0].soldiers - a[0].soldiers)[0];
      const target = game.countries.map((c, i) => [c, i]).filter(([c]) => c.owner !== 0).sort((a, b) => a[0].soldiers - b[0].soldiers)[0];
      if (!from || !target) break;
      engine.startAttack(from[1], target[1]);
      for (let roll = 0; roll < 30 && game.turn === 0 && !game.isOver; roll += 1) await engine.roll();
      if (game.turn === 0 && !game.isOver) await engine.fallBack();
      await engine.resume();
    }
    if (game.isOver) decided += 1;
  }
  assert.ok(decided >= 6, `only ${decided} of 12 games finished`);
});

test('halting stops NPC processing', async () => {
  const game = makeCustomGame({ soldiers: Array(10).fill(5), owners: OWNERS, turn: 1 });
  const { engine, errors } = makeEngine(game);
  engine.halt();
  await engine.resume();
  assert.equal(game.turn, 1);
  assert.deepEqual(errors, []);
});

test('fast mode toggles', () => {
  const { engine } = makeEngine(makeGame(1));
  assert.equal(engine.fast, false);
  assert.equal(engine.toggleFast(), true);
});

test('RuleError is exported for UI messages', () => {
  assert.ok(new RuleError('x') instanceof Error);
  assert.ok(Rng.seeded(1).int(6) >= 1);
});
