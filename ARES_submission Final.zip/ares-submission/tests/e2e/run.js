import assert from 'node:assert/strict';
import { createReadStream, existsSync, mkdirSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { MOCK_MODULES } from '../helpers/mockFirebase.js';

const root = resolve(fileURLToPath(new URL('../..', import.meta.url)));
const publicDir = join(root, 'public');
const shots = join(root, 'tests', 'e2e', 'screenshots');
mkdirSync(shots, { recursive: true });

const resolveAsset = (name) => join(root, 'node_modules', name);
const ASSETS = {
  'd3.min.js': resolveAsset('d3/dist/d3.min.js'),
  'topojson-client.min.js': resolveAsset('topojson-client/dist/topojson-client.min.js'),
  'countries-110m.json': resolveAsset('world-atlas/countries-110m.json'),
};

const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
const server = createServer((req, res) => {
  const path = normalize(decodeURIComponent(new URL(req.url, 'http://x').pathname)).replace(/^(\.\.[/\\])+/, '');
  let file = join(publicDir, path);
  if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
  if (!file.startsWith(publicDir) || !existsSync(file)) {
    res.writeHead(404).end('not found');
    return;
  }
  res.writeHead(200, { 'Content-Type': TYPES[extname(file)] ?? 'application/octet-stream' });
  createReadStream(file).pipe(res);
});
await new Promise((ok) => server.listen(0, ok));
const base = `http://localhost:${server.address().port}/`;

const results = [];
const check = (name, fn) => results.push({ name, fn });
const errors = [];

const prepare = async (context) => {
  await context.route(/gstatic\.com\/firebasejs\/.*\/(firebase-[a-z]+\.js)$/, (route) => {
    const file = route.request().url().split('/').pop();
    route.fulfill({ contentType: 'text/javascript', body: MOCK_MODULES[file] });
  });
  await context.route(/cdn\.jsdelivr\.net/, (route) => {
    const file = route.request().url().split('/').pop();
    route.fulfill({ contentType: file.endsWith('.json') ? 'application/json' : 'text/javascript', path: ASSETS[file] });
  });
  await context.route(/fonts\.(googleapis|gstatic)\.com/, (route) => route.fulfill({ contentType: 'text/css', body: '' }));
};

const watch = (page, label) => {
  page.on('pageerror', (e) => errors.push(`${label} pageerror: ${e.message}`));
  page.on('console', (m) => {
    if (m.type() === 'error') errors.push(`${label} console: ${m.text()}`);
  });
};

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1366, height: 900 }, deviceScaleFactor: 1 });
await prepare(context);
const page = await context.newPage();
watch(page, 'owner');
page.on('dialog', (d) => d.accept());
let gameUrl = '';

const text = (selector) => page.locator(selector).first().innerText();
const myTurn = () => page.waitForFunction(() => document.querySelector('#hud')?.textContent.includes('YOUR MOVE'), null, { timeout: 90000 });

const step = async (name, fn) => {
  try {
    await fn();
    console.log('PASS', name);
  } catch (e) {
    console.log('FAIL', name, '-', e.message.split('\n')[0]);
    errors.push(`${name}: ${e.message.split('\n')[0]}`);
    await page.screenshot({ path: join(shots, `fail-${name.replace(/\W+/g, '-')}.png`) }).catch(() => {});
  }
};

await step('login screen is shown to signed-out visitors', async () => {
  await page.goto(base);
  await page.waitForSelector('#auth-form');
  assert.match(await text('#auth-title'), /Jack in/);
  assert.match(await text('#userbar'), /Unplugged/);
  await page.screenshot({ path: join(shots, '1-login.png') });
});

await step('registration validates callsign, email and password', async () => {
  await page.click('[data-mode="register"]');
  await page.fill('#callsign', 'x');
  await page.fill('#email', 'tester@example.com');
  await page.fill('#password', 'abcdefg1');
  await page.click('#auth-form button[type="submit"]');
  assert.match(await text('#auth-error'), /Callsign must be/);
  await page.fill('#callsign', '<script>');
  await page.click('#auth-form button[type="submit"]');
  assert.match(await text('#auth-error'), /Callsign must be/);
  await page.fill('#callsign', 'Tester_01');
  await page.fill('#email', 'not-an-email');
  await page.click('#auth-form button[type="submit"]');
  assert.match(await text('#auth-error'), /email looks off/);
  await page.fill('#email', 'tester@example.com');
  await page.fill('#password', 'abcdefgh');
  await page.click('#auth-form button[type="submit"]');
  assert.match(await text('#auth-error'), /letter and one number/);
});

await step('registration creates the account and opens the lobby', async () => {
  await page.fill('#password', 'abcdefg1');
  await page.click('#auth-form button[type="submit"]');
  await page.waitForSelector('#deploy-form');
  assert.match(await text('#userbar'), /Tester_01/);
  assert.equal(await page.inputValue('#country'), 'South Africa');
  await page.waitForSelector('#mine-items .run, #mine-items small:has-text("No runs yet")');
  await page.screenshot({ path: join(shots, '2-lobby.png') });
});

await step('sign out and sign in again, wrong password is explained', async () => {
  await page.click('[data-act="logout"]');
  await page.waitForSelector('#auth-form');
  await page.fill('#email', 'tester@example.com');
  await page.fill('#password', 'wrongpass1');
  await page.click('#auth-form button[type="submit"]');
  await page.waitForFunction(() => /No match for that login/.test(document.querySelector('#auth-error').textContent));
  await page.fill('#password', 'abcdefg1');
  await page.click('#auth-form button[type="submit"]');
  await page.waitForSelector('#deploy-form');
});

await step('how-to-play dialog opens and closes with Escape', async () => {
  await page.click('[data-act="help"]');
  await page.waitForSelector('.dialog .howto');
  await page.keyboard.press('Escape');
  await page.waitForSelector('.dialog', { state: 'detached' });
});

await step('deploying a game opens the world map with 10 countries and South Africa', async () => {
  await page.selectOption('#country', 'Japan');
  await page.click('#deploy-form button[type="submit"]');
  await page.waitForSelector('#map .nd');
  gameUrl = page.url();
  assert.match(gameUrl, /\?g=[a-z0-9]{20}$/);
  assert.equal(await page.locator('#map .nd').count(), 10);
  assert.ok(await page.locator('#map .nd', { hasText: 'South Africa' }).count());
  assert.match(await text('#hud'), /Japan/);
  await page.waitForFunction(() => document.querySelectorAll('#land path[data-n]').length > 100);
  await page.screenshot({ path: join(shots, '3-game-start.png') });
});

await step('speed up and wait for the human turn', async () => {
  await page.click('[data-a="ff"]');
  await myTurn();
  assert.ok(await page.locator('.rw').count() === 10);
});

await step('place reinforcements when granted, then strike and roll with a missile', async () => {
  for (let i = 0; i < 10; i += 1) {
    const text = await page.locator('#hud').innerText();
    if (!/PLACE NOW/.test(text)) break;
    await page.locator('.rw', { hasText: 'YOU' }).first().click();
  }
  const own = page.locator('.rw', { hasText: 'YOU' }).first();
  await own.click();
  await page.locator('.rw', { hasText: 'NPC' }).first().click();
  await page.click('[data-a="atk"]');
  await page.waitForFunction(() => !document.querySelector('[data-a="roll"]').disabled);
  await page.click('[data-a="roll"]');
  await page.waitForSelector('#arcs use', { timeout: 3000 });
  await page.screenshot({ path: join(shots, '4-missile.png') });
  await page.waitForSelector('.die');
  assert.ok(await page.locator('#side .log div').count() > 2);
});

await step('state persists across a reload', async () => {
  await page.reload();
  await page.waitForSelector('#map .nd');
  assert.equal(await page.locator('#map .nd').count(), 10);
  assert.ok((await text('#side')).length > 100);
});

await step('mobile layout keeps the dock and HUD usable', async () => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(400);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  assert.ok(overflow <= 2, `horizontal overflow ${overflow}px`);
  await page.screenshot({ path: join(shots, '5-mobile.png') });
  await page.setViewportSize({ width: 1366, height: 900 });
});

await step('spectators can watch but never control', async () => {
  const guest = await browser.newContext({ viewport: { width: 1366, height: 900 } });
  await prepare(guest);
  await guest.addInitScript((db) => localStorage.setItem('__mock_db', db), await page.evaluate(() => localStorage.getItem('__mock_db')));
  const view = await guest.newPage();
  watch(view, 'guest');
  await view.goto(gameUrl);
  await view.waitForSelector('#map .nd');
  assert.match(await view.locator('#hud').innerText(), /SPECTATING|ACTING|YOUR MOVE|FLATLINED|OWN THE WORLD/);
  assert.equal(await view.locator('[data-a="roll"]').count(), 0);
  assert.equal(await view.locator('[data-a="atk"]').count(), 0);
  assert.ok(await view.locator('[data-a="share"]').count());
  await guest.close();
});

await step('invalid game links are refused', async () => {
  await page.goto(`${base}?g=../../etc/passwd`);
  await page.waitForSelector('text=Signal lost');
  await page.goto(`${base}?g=zzzzzzzzzzzzzzzzzzzz`);
  await page.waitForSelector('text=Signal lost');
});

await step('lobby lists, searches, filters and deletes runs', async () => {
  await page.goto(base);
  await page.waitForSelector('#mine-items .run');
  assert.ok(await page.locator('#mine-items .run').count() >= 1);
  assert.ok(await page.locator('#public-items .run').count() >= 1);
  await page.fill('[data-filter="mine"][data-field="q"]', 'zzz');
  await page.waitForSelector('#mine-items :text("No runs match")');
  await page.fill('[data-filter="mine"][data-field="q"]', 'jap');
  assert.equal(await page.locator('#mine-items .run').count(), 1);
  await page.selectOption('[data-filter="mine"][data-field="status"]', 'won');
  await page.waitForSelector('#mine-items :text("No runs match")');
  await page.selectOption('[data-filter="mine"][data-field="status"]', 'live');
  assert.equal(await page.locator('#mine-items .run').count(), 1);
  assert.match(await text('#stats'), /Runs/);
  await page.screenshot({ path: join(shots, '6-lobby-runs.png') });
});

await step('the nuke finale shows the hazard sign and VICTORY', async () => {
  await page.evaluate(() => {
    const db = JSON.parse(localStorage.getItem('__mock_db'));
    const key = Object.keys(db).find((k) => k.startsWith('games/'));
    const g = db[key];
    g.turn = 0;
    g.phase = 'act';
    g.pool = 0;
    g.attack = null;
    g.countries.forEach((c, i) => {
      c.owner = i === 9 ? 9 : 0;
      c.soldiers = i === 0 ? 60 : i === 9 ? 1 : 2;
    });
    g.players.forEach((p, i) => { p.alive = i === 0 || i === 9; });
    localStorage.setItem('__mock_db', JSON.stringify(db));
  });
  await page.locator('#mine-items .run-link').first().click();
  await page.waitForSelector('#map .nd');
  await myTurn();
  await page.locator('.rw', { hasText: 'YOU' }).first().click();
  await page.locator('.rw', { hasText: 'NPC' }).first().click();
  await page.click('[data-a="atk"]');
  for (let i = 0; i < 20; i += 1) {
    if (await page.locator('.modal').count()) break;
    if (await page.locator('[data-a="nuke"]').count()) break;
    await page.click('[data-a="roll"]', { timeout: 4000 }).catch(() => {});
    await page.waitForTimeout(250);
  }
  if (await page.locator('.modal').count()) await page.click('.modal [data-act="confirm"]');
  await page.waitForSelector('#boom .hz', { timeout: 15000 });
  await page.waitForSelector('#boom .vt', { timeout: 15000 });
  await page.waitForTimeout(4200);
  assert.match(await page.locator('#boom .vt').textContent(), /VICTORY/);
  await page.screenshot({ path: join(shots, '7-victory.png') });
  await page.click('#boom');
  assert.equal(await page.locator('#boom .hz').count(), 0);
  assert.match(await text('#hud'), /OWN THE WORLD/);
  assert.ok(await page.locator('[data-a="nuke"]').count());
});

await step('a finished run shows as WON and can be deleted', async () => {
  await page.goto(base);
  await page.waitForSelector('#mine-items .run');
  assert.ok(await page.locator('#mine-items .badge.won').count());
  await page.click('[data-delete]');
  await page.waitForSelector('#mine-items :text("No runs yet")');
});

await browser.close();
server.close();
const failed = errors.filter((e) => !/Failed to load resource/.test(e));
console.log(failed.length ? `\n${failed.length} problem(s):\n${failed.join('\n')}` : '\nE2E: all steps passed with no console errors');
process.exit(failed.length ? 1 : 0);
