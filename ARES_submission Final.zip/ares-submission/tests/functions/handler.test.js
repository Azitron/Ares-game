import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { beforeEach, test } from 'node:test';

const require = createRequire(import.meta.url);
const { makeHandler } = require('../../functions/src/handler.js');
const { RateLimiter } = require('../../functions/src/RateLimiter.js');
const { createChat } = require('../../functions/src/openai.js');

const board = [{ n: 'Japan', o: 0, s: 5 }, { n: 'Cuba', o: 1, s: 2 }, { n: 'Chile', o: 0, s: 1 }, { n: 'Iceland', o: 2, s: 1 }];
const response = () => {
  const r = { headers: {}, code: 200, body: undefined };
  r.set = (k, v) => { r.headers[k] = v; };
  r.status = (c) => { r.code = c; return r; };
  r.json = (b) => { r.body = b; return r; };
  r.send = (b) => { r.body = b; return r; };
  return r;
};
const request = (o = {}) => ({ method: 'POST', body: {}, get: (k) => ({ origin: o.origin, authorization: o.auth })[k.toLowerCase()], ...o });
let limiter;
const build = (chat = async () => 'x') =>
  makeHandler({
    origins: () => ['https://ok.web.app'],
    verify: async (token) => { if (token === 'good') return { uid: 'u1' }; throw new Error('bad'); },
    chat,
    limiter,
  });
const run = async (handler, req) => { const res = response(); await handler(req, res); return res; };

beforeEach(() => { limiter = new RateLimiter({ max: 5, windowMs: 60000 }); });

test('rejects missing and invalid tokens', async () => {
  assert.equal((await run(build(), request())).body.error, 'login_required');
  assert.equal((await run(build(), request({ auth: 'Bearer nope' }))).code, 401);
});

test('CORS preflight is allowed only for configured origins', async () => {
  const ok = await run(build(), request({ method: 'OPTIONS', origin: 'https://ok.web.app' }));
  assert.equal(ok.code, 204);
  assert.equal(ok.headers['Access-Control-Allow-Origin'], 'https://ok.web.app');
  const bad = await run(build(), request({ method: 'OPTIONS', origin: 'https://evil.com' }));
  assert.equal(bad.code, 403);
  assert.equal(bad.headers['Access-Control-Allow-Origin'], undefined);
  assert.equal((await run(build(), request({ origin: 'https://evil.com', auth: 'Bearer good', body: { type: 'commentary', event: 'x' } }))).code, 403);
  assert.equal((await run(build(), request({ method: 'GET', auth: 'Bearer good' }))).code, 405);
});

test('commentary is trimmed and requires an event', async () => {
  const res = await run(build(async () => '  Japan  hammers\nCuba.  '), request({ origin: 'https://ok.web.app', auth: 'Bearer good', body: { type: 'commentary', event: 'Japan [1,6] vs Cuba [6,5] -> -1/-1' } }));
  assert.equal(res.body.text, 'Japan hammers Cuba.');
  assert.equal((await run(build(), request({ auth: 'Bearer good', body: { type: 'commentary', event: '' } }))).code, 400);
});

test('decide accepts only legal moves', async () => {
  const ask = (reply) => run(build(async () => reply), request({ auth: 'Bearer good', body: { type: 'decide', me: 0, board } }));
  const good = await ask('```json\n{"from":"Japan","to":"Cuba","why":"Edge of +2."}\n```');
  assert.deepEqual([good.body.from, good.body.to], ['Japan', 'Cuba']);
  assert.equal((await ask('{"from":"Chile","to":"Cuba","why":"x"}')).body.from, null);
  assert.equal((await ask('{"from":"Cuba","to":"Japan","why":"x"}')).body.from, null);
  assert.equal((await ask('{"from":"Japan","to":"Chile","why":"x"}')).body.from, null);
  const garbage = await ask('lol no json');
  assert.equal(garbage.code, 200);
  assert.equal(garbage.body.from, null);
});

test('malformed requests are rejected', async () => {
  assert.equal((await run(build(), request({ auth: 'Bearer good', body: { type: 'decide', me: 0, board: [] } }))).code, 400);
  assert.equal((await run(build(), request({ auth: 'Bearer good', body: { type: 'nope' } }))).code, 400);
});

test('upstream failures return 502 without leaking details', async () => {
  const res = await run(build(async () => { throw new Error('OpenAI 401 sk-secret'); }), request({ auth: 'Bearer good', body: { type: 'commentary', event: 'x' } }));
  assert.equal(res.code, 502);
  assert.ok(!JSON.stringify(res.body).includes('sk-'));
});

test('rate limiting returns 429 after the quota', async () => {
  let last;
  for (let i = 0; i < 6; i += 1) last = await run(build(), request({ auth: 'Bearer good', body: { type: 'commentary', event: 'x' } }));
  assert.equal(last.code, 429);
});

test('OpenAI client sends the key server-side and parses the reply', async () => {
  let seen;
  const fetchFn = async (url, init) => { seen = { url, init }; return { ok: true, json: async () => ({ choices: [{ message: { content: 'hello' } }] }) }; };
  const chat = createChat({ apiKey: () => 'sk-test', model: () => 'm', fetchFn });
  assert.equal(await chat([{ role: 'user', content: 'x' }]), 'hello');
  assert.equal(seen.init.headers.Authorization, 'Bearer sk-test');
  assert.equal(JSON.parse(seen.init.body).model, 'm');
  const failing = createChat({ apiKey: () => 'k', model: () => 'm', fetchFn: async () => ({ ok: false, status: 429, text: async () => 'limit' }) });
  await assert.rejects(() => failing([]), /OpenAI 429/);
});
